import { Component, input, output, ChangeDetectionStrategy, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-confirmation-modal',
  standalone: true,
  imports: [CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 bg-black/40 z-40" (click)="cancel.emit()"></div>
    <div 
      role="dialog" 
      aria-modal="true"
      [attr.aria-labelledby]="titleId"
      class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-xl p-6 sm:p-8 w-[90vw] max-w-md z-50 max-h-[90vh] overflow-y-auto"
    >
      <h2 [id]="titleId" class="text-xl font-bold text-gray-800 mb-4">{{ title() }}</h2>
      <p class="text-gray-600 mb-6">{{ message() }}</p>
      <div class="flex justify-end gap-3">
        <button (click)="cancel.emit()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">
          Cancel
        </button>
        <button (click)="confirm.emit()" class="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700">
          Confirm
        </button>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfirmationModalComponent {
  title = input<string>('Are you sure?');
  message = input.required<string>();
  confirm = output<void>();
  cancel = output<void>();
  
  readonly titleId = 'confirmation-modal-title';

  @HostListener('document:keydown.escape')
  onEscapeKey() {
    this.cancel.emit();
  }
}