import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  currentUser = signal<any | null>(null);

  constructor(private router: Router) {
    this.loadUserFromStorage();
  }

  private loadUserFromStorage() {
    const admin = localStorage.getItem('admin');
    const employee = localStorage.getItem('employee');
    if (admin) {
      this.currentUser.set({ ...JSON.parse(admin), role: 'admin' });
    } else if (employee) {
      this.currentUser.set({ ...JSON.parse(employee), role: 'employee' });
    }
  }

  isLoggedIn(): boolean {
    return !!this.currentUser();
  }

  hasRole(role: 'admin' | 'employee'): boolean {
    return this.currentUser()?.role === role;
  }

  login(user: any, role: 'admin' | 'employee') {
    localStorage.setItem(role, JSON.stringify(user));
    this.currentUser.set({ ...user, role });
  }

  logout() {
    localStorage.removeItem('admin');
    localStorage.removeItem('employee');
    this.currentUser.set(null);
    this.router.navigate(['/']);
  }
}
