import { inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
// FIX: Use modern rxjs import path for operators
import { delay } from 'rxjs';
import { ToastService } from './toast.service';

// Removed @Injectable to prevent DI conflicts
export class ApiService {
  // FIX: Explicitly type http property as HttpClient to resolve type inference error.
  private http: HttpClient = inject(HttpClient);
  
  // Placeholders - in a real app these come from env
  projectId = 'your-project-id';
  publicAnonKey = 'your-anon-key';
  
  // Toggle this if you want to force mock mode locally
  useMock = true;

  // In-memory mock state for the session
  private mockAttendance: any[] = [];
  
  private mockEmployees = [
    { id: '101', name: 'John Doe', role: 'Developer', email: 'john.doe@example.com', salary: 80000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '102', name: 'Jane Smith', role: 'Designer', email: 'jane.smith@example.com', salary: 75000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '103', name: 'Robert Johnson', role: 'Manager', email: 'robert.j@example.com', salary: 95000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '104', name: 'Emily White', role: 'QA Tester', email: 'emily.w@example.com', salary: 65000, schedule: { mon: true, tue: false, wed: true, thu: true, fri: true, sat: false, sun: false } },
  ];

  constructor() {
    // Initialize with some history
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    this.mockAttendance = [
      { 
        date: yesterday.toLocaleDateString('en-CA'), 
        check_in: new Date(yesterday.setHours(9, 0, 0, 0)).toISOString(), 
        check_out: new Date(yesterday.setHours(17, 30, 0, 0)).toISOString(), 
        hours: '8.5' 
      }
    ];
  }

  get baseUrl() {
    return `https://${this.projectId}.supabase.co/functions/v1/make-server-5188af6b`;
  }

  private get headers() {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.publicAnonKey}`,
      'Content-Type': 'application/json'
    });
  }

  // --- MOCK DATA GENERATORS ---
  private mockDelay<T>(data: T, ms = 600): Observable<T> {
    return of(data).pipe(delay(ms));
  }

  // FIX: Add explicit return type for API methods
  checkDatabaseSetup(): Observable<{ ready: boolean; errors?: string[] }> {
    if (this.useMock) return this.mockDelay({ ready: true });
    return this.http.get<{ ready: boolean; errors?: string[] }>(`${this.baseUrl}/setup/check`, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  adminLogin(loginData: any): Observable<{ success: boolean; admin?: any; error?: string }> {
    if (this.useMock) {
      if (loginData.username === 'admin' && loginData.password === 'admin') {
        return this.mockDelay({
          success: true,
          admin: { username: 'admin', role: 'manager', name: 'Admin User' }
        });
      }
      return this.mockDelay({ success: false, error: 'Invalid admin credentials' });
    }
    return this.http.post<{ success: boolean; admin?: any; error?: string }>(`${this.baseUrl}/admin/login`, loginData, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  employeeLogin(loginData: any): Observable<{ success: boolean; employee?: any; error?: string }> {
    if (this.useMock) {
       // Allow any login for demo
       return this.mockDelay({
         success: true,
         employee: { id: loginData.employeeId, name: 'John Doe', role: 'Staff' }
       });
    }
    return this.http.post<{ success: boolean; employee?: any; error?: string }>(`${this.baseUrl}/employee/login`, loginData, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  getEmployeeHistory(employeeId: string): Observable<{ attendance: any[]; summary: any }> {
    if (this.useMock) {
      return this.mockDelay({
        attendance: [...this.mockAttendance],
        summary: {
            leaveDaysAvailable: 15,
            sickDaysTaken: 2,
            pendingClaims: 1
        }
      });
    }
    return this.http.get<{ attendance: any[]; summary: any }>(`${this.baseUrl}/employee/${employeeId}/history`, { headers: this.headers });
  }

  getEmployeeDetails(employeeId: string): Observable<any> {
    if (this.useMock) {
      const employee = this.mockEmployees.find(e => e.id === employeeId);

      const mockData = {
        details: employee,
        attendance: [
          { date: '2024-07-29', check_in: '08:55 AM', check_out: '05:30 PM', hours: 8.6 },
          { date: '2024-07-28', check_in: '09:05 AM', check_out: '05:35 PM', hours: 8.5 }
        ],
        leave: [
          { from: '2024-08-10', to: '2024-08-15', reason: 'Vacation', status: 'Approved' }
        ],
        claims: [
          { date: '2024-07-20', amount: '$75.00', description: 'Team Dinner', status: 'Reimbursed' }
        ]
      };
      return this.mockDelay(mockData);
    }
    // Real API call would go here
    return this.http.get<any>(`${this.baseUrl}/admin/employee/${employeeId}`, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  getEmployees(): Observable<any[]> {
    if (this.useMock) {
        return this.mockDelay([...this.mockEmployees]);
    }
    return this.http.get<any[]>(`${this.baseUrl}/admin/employees`, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  addEmployee(employeeData: any): Observable<{ success: boolean; employee?: any; error?: string }> {
      if (this.useMock) {
          const newEmployee = {
              id: (Math.max(...this.mockEmployees.map(e => parseInt(e.id))) + 1).toString(),
              ...employeeData,
              schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } // default schedule
          };
          this.mockEmployees.push(newEmployee);
          return this.mockDelay({ success: true, employee: newEmployee });
      }
      return this.http.post<{ success: boolean; employee?: any; error?: string }>(`${this.baseUrl}/admin/employees`, employeeData, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  updateEmployee(employeeData: any): Observable<{ success: boolean; employee?: any; error?: string }> {
      if (this.useMock) {
          const index = this.mockEmployees.findIndex(e => e.id === employeeData.id);
          if (index !== -1) {
              this.mockEmployees[index] = { ...this.mockEmployees[index], ...employeeData };
              return this.mockDelay({ success: true, employee: this.mockEmployees[index] });
          }
          return this.mockDelay({ success: false, error: 'Employee not found' });
      }
      return this.http.put<{ success: boolean; employee?: any; error?: string }>(`${this.baseUrl}/admin/employees/${employeeData.id}`, employeeData, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  updateSchedule(data: { employeeId: string, schedule: any }): Observable<{ success: boolean; error?: string }> {
      if (this.useMock) {
          const index = this.mockEmployees.findIndex(e => e.id === data.employeeId);
          if (index !== -1) {
              this.mockEmployees[index].schedule = data.schedule;
              return this.mockDelay({ success: true });
          }
          return this.mockDelay({ success: false, error: 'Employee not found' });
      }
      return this.http.post<{ success: boolean; error?: string }>(`${this.baseUrl}/admin/employees/${data.employeeId}/schedule`, data.schedule, { headers: this.headers });
  }


  // FIX: Add explicit return type for API methods
  checkIn(data: any): Observable<{ success: boolean; error?: string }> {
    if (this.useMock) {
      const todayStr = new Date().toLocaleDateString('en-CA');
      const now = new Date();
      
      const existing = this.mockAttendance.find(a => a.date === todayStr);
      if (!existing) {
        this.mockAttendance.push({
          date: todayStr,
          check_in: now.toISOString(),
          check_out: null,
          hours: null
        });
      }
      return this.mockDelay({ success: true });
    }
    return this.http.post<{ success: boolean; error?: string }>(`${this.baseUrl}/attendance/checkin`, data, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  checkOut(data: any): Observable<{ success: boolean; hours?: string; error?: string }> {
    if (this.useMock) {
      const todayStr = new Date().toLocaleDateString('en-CA');
      const now = new Date();
      
      const existing = this.mockAttendance.find(a => a.date === todayStr);
      if (existing) {
        existing.check_out = now.toISOString();
        // Simple hours calculation
        const start = new Date(existing.check_in);
        const hours = (now.getTime() - start.getTime()) / (1000 * 60 * 60);
        existing.hours = hours.toFixed(2);
        return this.mockDelay({ success: true, hours: existing.hours });
      }
      return this.mockDelay({ success: false, error: "No check-in found for today" });
    }
    return this.http.post<{ success: boolean; hours?: string; error?: string }>(`${this.baseUrl}/attendance/checkout`, data, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  submitLeaveRequest(data: any): Observable<{ success: boolean }> {
    if (this.useMock) {
      console.log('Mock Leave Request Submitted:', data);
      return this.mockDelay({ success: true });
    }
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/leave`, data, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  submitSickReport(data: any): Observable<{ success: boolean }> {
    if (this.useMock) {
      console.log('Mock Sick Report Submitted:', data);
      return this.mockDelay({ success: true });
    }
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/sick`, data, { headers: this.headers });
  }

  // FIX: Add explicit return type for API methods
  submitExpenseClaim(data: any): Observable<{ success: boolean }> {
    if (this.useMock) {
      console.log('Mock Expense Claim Submitted:', data);
      return this.mockDelay({ success: true });
    }
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/claim`, data, { headers: this.headers });
  }
}
