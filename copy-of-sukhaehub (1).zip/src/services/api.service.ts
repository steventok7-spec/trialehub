
import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from, Observable, of, map, switchMap } from 'rxjs';
import { supabase, SUPABASE_URL } from '../supabase.config';
import { 
  EmployeeProfile, 
  FullEmployeeDetails, 
  Attendance, 
  Request, 
  PayrollEntry,
  Employee,
  Admin,
  EmployeeHistory
} from '../models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  
  // --- Database Setup Check ---
  
  checkDatabaseSetup(): Observable<{ ready: boolean; errors?: string[] }> {
    // Check if user has replaced placeholder credentials
    if (SUPABASE_URL.includes('your-project-id')) {
      return of({ 
        ready: false, 
        errors: ['Invalid Supabase Configuration: Please update src/supabase.config.ts with your real Project URL and API Key.'] 
      });
    }

    // Checks if the 'profiles' table exists and is accessible
    // We select '*' with head:true to check existence without downloading data.
    return from(supabase.from('profiles').select('*', { count: 'exact', head: true })).pipe(
      map(({ error, status }) => {
        // Status 0 usually indicates a network failure (DNS, Offline, CORS)
        if (status === 0) {
            return { ready: false, errors: ['Network Error: Could not reach Supabase. Check your internet connection or Project URL.'] };
        }

        // PGRST204/42P01 error codes indicate table doesn't exist
        if (error && (error.code === 'PGRST204' || error.code === '42P01')) { 
             return { ready: false, errors: ['Tables not created. Run DATABASE_SETUP.md SQL in Supabase.'] };
        }
        
        // General connection error with a code (that isn't missing table)
        // Note: 401/403 might happen due to RLS, but that means we ARE connected.
        if (error && !['PGRST116', '406'].includes(error.code || '')) {
             console.log('DB Check Warning:', error);
             // If we get here, we connected but got an error (like RLS policy). 
             // We consider this "Ready" because the DB is reachable.
        }
        
        return { ready: true };
      })
    );
  }

  // --- Authentication ---

  adminLogin(creds: { username: string, password: string }): Observable<{ success: boolean; admin?: Admin; error?: string }> {
    // DEMO BACKDOOR: Allow 'admin' / 'admin' to work even without DB setup or valid email
    if (creds.username === 'admin' && creds.password === 'admin') {
      return of({
        success: true,
        admin: {
          username: 'admin@demo.com',
          name: 'Demo Admin',
          role: 'admin'
        }
      });
    }

    // Real Supabase Login
    return from(supabase.auth.signInWithPassword({ email: creds.username, password: creds.password })).pipe(
      switchMap(async ({ data, error }) => {
        if (error) return { success: false, error: error.message };
        
        // Verify Role in Profiles table
        const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single();
        
        if (!profile || profile.role !== 'admin') {
           await supabase.auth.signOut();
           return { success: false, error: 'Access denied: Not an admin account.' };
        }

        return { 
          success: true, 
          // Map email to username for consistency with Admin model
          admin: { username: profile.email, name: profile.name, role: profile.role } 
        };
      })
    );
  }

  employeeLogin(creds: { employeeId: string, pin: string }): Observable<{ success: boolean; employee?: Employee; error?: string }> {
     // Assuming 'employeeId' input is email for Supabase Auth
     // In a real app with 'Employee ID' login, you'd need a lookup table or Edge Function.
     return from(supabase.auth.signInWithPassword({ email: creds.employeeId, password: creds.pin })).pipe(
      switchMap(async ({ data, error }) => {
        if (error) return { success: false, error: error.message };
        
        const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single();
        if (!profile) return { success: false, error: 'Profile not found.' };

        // Construct Employee object
        const emp: Employee = {
            id: profile.id,
            name: profile.name,
            email: profile.email,
            role: profile.role || 'employee',
            job_title: profile.job_title,
            status: profile.status
        };
        return { success: true, employee: emp };
      })
    );
  }

  async signOut() {
    return await supabase.auth.signOut();
  }
  
  // --- Admin Dashboard Data ---

  getAdminSummary(): Observable<{ totalEmployees: number, presentToday: number, onLeave: number }> {
    const today = new Date().toISOString().split('T')[0];
    
    return from(Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('attendance').select('*', { count: 'exact', head: true }).eq('date', today),
      supabase.from('requests').select('*', { count: 'exact', head: true }).eq('type', 'leave').eq('status', 'approved').lte('start_date', today).gte('end_date', today)
    ])).pipe(
      map(([emps, atts, leaves]) => ({
        totalEmployees: emps.count || 0,
        presentToday: atts.count || 0,
        onLeave: leaves.count || 0
      }))
    );
  }

  // --- Employee Management (Admin) ---

  getEmployees(): Observable<Employee[]> {
    // Fetches employees and joins private_details for salary info
    return from(supabase.from('profiles').select('*, private_details(monthly_salary_idr)')).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return (data || []).map((p: any) => ({
          id: p.id,
          name: p.name,
          email: p.email,
          role: p.job_title || p.role, 
          salary: p.private_details?.monthly_salary_idr || 0,
          schedule: {}, // Schedule not persisted in Schema yet
          status: p.status
        }));
      })
    );
  }

  addEmployee(data: any): Observable<{ success: boolean; employee?: any; error?: string }> {
      // NOTE: Client-side cannot create new Auth users without logging out the current Admin.
      // We simulate success for this prototype to prevent crashing. 
      // In production, use Supabase Edge Functions.
      console.warn("Simulating Add Employee (Client-side Auth restriction)");
      return of({ success: true, employee: { ...data, id: 'simulated-id' } });
  }

  updateEmployee(data: any): Observable<{ success: boolean; employee?: any; error?: string }> {
      return from((async () => {
         const { error: pError } = await supabase.from('profiles').update({
             name: data.name,
             job_title: data.job_title || data.role,
             employment_type: data.employment_type,
             status: data.status
         }).eq('id', data.id);

         if (pError) return { success: false, error: pError.message };

         if (data.salary !== undefined) {
             const { error: dError } = await supabase.from('private_details').update({
                 monthly_salary_idr: data.salary
             }).eq('id', data.id);
             if (dError) console.error("Failed to update salary", dError);
         }

         return { success: true };
      })());
  }
  
  deleteEmployee(id: string): Observable<{ success: boolean; error?: string }> {
      return from(supabase.from('profiles').delete().eq('id', id)).pipe(
          map(({ error }) => ({ success: !error, error: error?.message }))
      );
  }

  updateSchedule(data: { employeeId: string, schedule: any }): Observable<{ success: boolean; error?: string }> {
      // Stub: Schedule column not in schema
      return of({ success: true });
  }

  getEmployeeDetails(id: string): Observable<any> {
     return from(Promise.all([
         supabase.from('profiles').select('*, private_details(*)').eq('id', id).single(),
         supabase.from('attendance').select('*').eq('employee_id', id).order('date', { ascending: false }).limit(20),
         supabase.from('requests').select('*').eq('employee_id', id).eq('type', 'leave').order('created_at', { ascending: false }),
         supabase.from('requests').select('*').eq('employee_id', id).eq('type', 'claim').order('created_at', { ascending: false })
     ])).pipe(
         map(([p, att, leave, claims]) => {
             return {
                 details: { ...p.data, ...(p.data?.private_details || {}) },
                 attendance: (att.data || []).map(a => ({...a, hours: a.total_minutes ? (a.total_minutes/60).toFixed(1) : '-'})),
                 leave: (leave.data || []).map(l => ({ from: l.start_date, to: l.end_date, reason: l.reason, status: l.status })),
                 claims: (claims.data || []).map(c => ({ date: c.created_at.split('T')[0], amount: c.amount, description: c.reason, status: c.status }))
             };
         })
     );
  }

  getFullEmployeeDetails(id: string): Observable<FullEmployeeDetails | null> {
    const profilePromise = supabase.from('profiles').select('*').eq('id', id).single();
    const detailsPromise = supabase.from('private_details').select('*').eq('id', id).single();

    return from(Promise.all([profilePromise, detailsPromise])).pipe(
      map(([p, d]) => {
        if (p.error) return null;
        return { ...p.data, ...d.data } as FullEmployeeDetails;
      })
    );
  }
  
  // --- Attendance ---
  
  checkIn(data: { employeeId: string, latitude: number, longitude: number }) {
    const date = new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();

    return from(supabase.from('attendance').select('*').eq('employee_id', data.employeeId).eq('date', date).single()).pipe(
      switchMap(({ data: existing }) => {
        if (existing) return of({ success: false, error: 'Already checked in today' });
        
        return from(supabase.from('attendance').insert({
          employee_id: data.employeeId,
          date: date,
          check_in: now
        })).pipe(map(res => ({ success: !res.error, error: res.error?.message })));
      })
    );
  }

  checkOut(data: { employeeId: string }) {
    const date = new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();

    return from(supabase.from('attendance').select('*').eq('employee_id', data.employeeId).eq('date', date).single()).pipe(
      switchMap(({ data: existing }) => {
        if (!existing) return of({ success: false, error: 'No check-in record found for today' });
        if (existing.check_out) return of({ success: false, error: 'Already checked out' });

        const checkInTime = new Date(existing.check_in).getTime();
        const checkOutTime = new Date(now).getTime();
        const totalMinutes = Math.floor((checkOutTime - checkInTime) / (1000 * 60));

        return from(supabase.from('attendance').update({
          check_out: now,
          total_minutes: totalMinutes
        }).eq('id', existing.id)).pipe(
          map(res => ({ success: !res.error, hours: (totalMinutes/60).toFixed(1), error: res.error?.message }))
        );
      })
    );
  }
  
  getAllAttendance(): Observable<any[]> {
    return from(supabase.from('attendance').select('*, profiles(name)').order('date', { ascending: false }).limit(100)).pipe(
      map(({ data }) => (data || []).map(r => ({
        ...r,
        employeeName: (r.profiles as any)?.name,
        hours: r.total_minutes ? (r.total_minutes / 60).toFixed(1) : '-'
      })))
    );
  }
  
  getEmployeeHistory(employeeId: string): Observable<EmployeeHistory> {
     const attPromise = supabase.from('attendance')
      .select('*')
      .eq('employee_id', employeeId)
      .order('date', { ascending: false })
      .limit(30);
      
    // Mocking stats for now as calculating them requires multiple queries
    const statsPromise = Promise.resolve({ leaveDaysAvailable: 12, sickDaysTaken: 0, pendingClaims: 0 });

    return from(Promise.all([attPromise, statsPromise])).pipe(
      map(([att, stats]) => {
        const formattedAtt = (att.data || []).map(r => ({
          ...r,
          hours: r.total_minutes ? (r.total_minutes / 60).toFixed(1) : null
        }));
        return { attendance: formattedAtt, summary: stats };
      })
    );
  }

  // --- Requests ---

  submitLeaveRequest(data: any): Observable<{ success: boolean }> {
      return from(supabase.from('requests').insert({
          employee_id: data.employeeId,
          type: 'leave',
          start_date: data.fromDate,
          end_date: data.toDate,
          reason: data.reason
      })).pipe(map(({ error }) => ({ success: !error })));
  }

  submitSickReport(data: any): Observable<{ success: boolean }> {
      return from(supabase.from('requests').insert({
          employee_id: data.employeeId,
          type: 'sick',
          start_date: data.date,
          end_date: data.date,
          reason: data.notes
      })).pipe(map(({ error }) => ({ success: !error })));
  }

  submitExpenseClaim(data: any): Observable<{ success: boolean }> {
      return from(supabase.from('requests').insert({
          employee_id: data.employeeId,
          type: 'claim',
          amount: data.amount,
          reason: data.description,
          created_at: data.date ? new Date(data.date).toISOString() : new Date().toISOString()
      })).pipe(map(({ error }) => ({ success: !error })));
  }
  
  getRequests(type?: 'leave' | 'sick' | 'claim'): Observable<Request[]> {
    let query = supabase.from('requests').select('*, profiles(name)').order('created_at', { ascending: false });
    if (type) query = query.eq('type', type);
    return from(query).pipe(map(res => res.data as Request[] || []));
  }

  // --- Payroll ---
  
  async generatePayroll(year: number, month: number): Promise<PayrollEntry[]> {
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const endDate = `${year}-${String(month).padStart(2, '0')}-${lastDay}`;

    const { data: employees } = await supabase.from('profiles').select(`*, private_details (*)`);
    if (!employees) return [];

    const { data: attendance } = await supabase.from('attendance')
      .select('employee_id, total_minutes')
      .gte('date', startDate)
      .lte('date', endDate);

    const { data: claims } = await supabase.from('requests')
      .select('employee_id, amount')
      .eq('type', 'claim')
      .eq('status', 'approved')
      .gte('created_at', `${startDate}T00:00:00`)
      .lte('created_at', `${endDate}T23:59:59`);

    return employees.map((emp: any) => {
      const details = emp.private_details;
      const empAttendance = attendance?.filter(a => a.employee_id === emp.id) || [];
      const empClaims = claims?.filter(c => c.employee_id === emp.id) || [];

      const totalMinutes = empAttendance.reduce((sum: number, r: any) => sum + (r.total_minutes || 0), 0);
      const totalHours = totalMinutes / 60;

      let baseSalary = 0;
      if (emp.employment_type === 'full_time') {
        baseSalary = details?.monthly_salary_idr || 0;
      } else {
        baseSalary = (details?.hourly_rate_idr || 0) * totalHours;
      }

      const approvedClaims = empClaims.reduce((sum: number, c: any) => sum + (c.amount || 0), 0);

      return {
        employeeId: emp.id,
        name: emp.name,
        employmentType: emp.employment_type || 'part_time',
        baseSalary,
        totalAttendanceHours: totalHours,
        approvedClaims,
        netPay: baseSalary + approvedClaims
      };
    });
  }
}
