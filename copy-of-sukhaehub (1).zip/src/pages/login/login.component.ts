
import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastService } from '../../services/toast.service';
import { AuthService } from '../../auth/auth.service';
import { IconComponent } from '../../components/ui/icon.component';
import { finalize } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-[#f8f9fb] to-[#e8eaf0] flex items-center justify-center p-6 relative">
      
      <!-- Connection Status Indicator -->
      <div class="absolute top-6 right-6 z-10">
        @if (checkingDb()) {
          <div class="flex items-center gap-2 px-3 py-1.5 bg-white/50 backdrop-blur rounded-full border border-gray-200 shadow-sm">
            <div class="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span class="text-xs font-medium text-gray-600">Connecting...</span>
          </div>
        } @else if (dbStatus()?.ready) {
          <div class="flex items-center gap-2 px-3 py-1.5 bg-green-50 backdrop-blur rounded-full border border-green-200 shadow-sm">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-xs font-bold text-green-700">System Online</span>
          </div>
        } @else {
          <button (click)="checkDatabaseSetup()" class="flex items-center gap-2 px-3 py-1.5 bg-red-50 hover:bg-red-100 backdrop-blur rounded-full border border-red-200 shadow-sm transition-colors group">
            <div class="w-2 h-2 bg-red-500 rounded-full group-hover:animate-ping"></div>
            <span class="text-xs font-bold text-red-700">Offline (Retry)</span>
          </button>
        }
      </div>

      <div class="w-full max-w-md">
        <!-- Logo Section -->
        <div class="text-center mb-12">
          <h1 class="font-bold text-[#1a1d29] mb-2 text-[40px]">SUKHA</h1>
          <p class="text-sm text-[#6b7280] font-medium">Employee Management Hub</p>
        </div>

        <!-- Database Status Warning -->
        @if (dbStatus() && !dbStatus()!.ready) {
          <div class="mb-6 p-4 bg-[#fef2f2] border-l-4 border-[#ef4444] rounded-r-xl shadow-sm">
            <div class="flex gap-3">
              <app-icon name="alert-triangle" class="w-5 h-5 text-[#ef4444] flex-shrink-0 mt-0.5" />
              <div>
                <h3 class="text-sm font-bold text-[#991b1b] mb-1">Database Connection Failed</h3>
                <p class="text-xs text-[#7f1d1d] leading-relaxed mb-2">
                  Could not connect to Supabase.
                </p>
                @if (dbStatus()?.errors && dbStatus()!.errors.length > 0) {
                  <ul class="text-xs text-[#7f1d1d] list-disc list-inside space-y-1 bg-[#fee2e2] p-2 rounded mt-2">
                    @for (error of dbStatus()?.errors; track $index) {
                      <li>{{ error }}</li>
                    }
                  </ul>
                  <p class="text-[10px] text-[#7f1d1d] mt-2 italic">
                     Check <code>src/supabase.config.ts</code>
                  </p>
                }
              </div>
            </div>
          </div>
        }

        <!-- Login Form -->
        <div class="bg-white rounded-3xl shadow-xl p-8 border border-[#e5e7eb]">
          <h2 class="font-bold text-[#1a1d29] mb-6 text-center text-[24px]">Sign In</h2>
          
          <form (submit)="handleLogin($event)" class="space-y-5">
            <!-- Login ID Input -->
            <div>
              <label class="block text-sm font-medium text-[#6b7280] mb-2">
                Email / Login ID
              </label>
              <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <app-icon name="user" class="w-5 h-5 text-[#9ca3af]" />
                </div>
                <input
                  type="text"
                  [(ngModel)]="loginId"
                  name="loginId"
                  placeholder="admin@example.com or ID"
                  class="w-full pl-12 pr-4 py-3.5 border border-transparent bg-[#f3f4f6] rounded-xl text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6366f1] transition-all"
                />
              </div>
            </div>

            <!-- Password Input -->
            <div>
              <label class="block text-sm font-medium text-[#6b7280] mb-2">
                Password
              </label>
              <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <app-icon name="lock" class="w-5 h-5 text-[#9ca3af]" />
                </div>
                <input
                  [type]="showPassword() ? 'text' : 'password'"
                  [(ngModel)]="password"
                  name="password"
                  placeholder="Enter your password"
                  class="w-full pl-12 pr-12 py-3.5 border border-transparent bg-[#f3f4f6] rounded-xl text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6366f1] transition-all"
                />
                <button
                  type="button"
                  (click)="togglePassword()"
                  class="absolute inset-y-0 right-0 pr-4 flex items-center"
                >
                  @if (showPassword()) {
                    <app-icon name="eye-off" class="w-5 h-5 text-[#9ca3af] hover:text-[#6b7280]" />
                  } @else {
                    <app-icon name="eye" class="w-5 h-5 text-[#9ca3af] hover:text-[#6b7280]" />
                  }
                </button>
              </div>
            </div>

            <!-- Login Button -->
            <button
              type="submit"
              [disabled]="loading()"
              class="w-full py-4 bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] text-white rounded-xl font-semibold hover:from-[#5558e3] hover:to-[#7c3aed] transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed mt-6 flex justify-center items-center"
            >
              @if (loading()) {
                <div class="flex items-center justify-center gap-2">
                  <div class="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Signing in...</span>
                </div>
              } @else {
                Sign In
              }
            </button>
          </form>

          <!-- Help Text -->
          <div class="mt-6 pt-6 border-t border-[#e5e7eb] space-y-3">
            <p class="text-xs text-[#9ca3af] text-center leading-relaxed">Enter your registered Email or ID.</p>
            <div class="text-xs text-center text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-200">
                <p class="font-semibold mb-1 text-gray-700">Demo Credentials (Bypass DB)</p>
                <p><strong class="font-medium text-gray-600">Admin:</strong> admin / admin</p>
            </div>
            
            <div class="text-center pt-2">
                <button type="button" (click)="testConnection()" class="text-[10px] text-indigo-500 hover:text-indigo-700 font-medium hover:underline focus:outline-none">
                    Test Database Connection
                </button>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="mt-8 text-center">
          <p class="text-xs text-[#9ca3af]">
            © 2026 SUKHA. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  private router = inject(Router);
  private authService = inject(AuthService);

  loginId = '';
  password = '';
  showPassword = signal(false);
  loading = signal(false);
  dbStatus = signal<{ ready: boolean; errors?: string[] } | null>(null);
  checkingDb = signal(true);

  ngOnInit() {
    this.checkDatabaseSetup();
  }

  togglePassword() {
    this.showPassword.update(v => !v);
  }

  checkDatabaseSetup() {
    this.checkingDb.set(true);
    this.api.checkDatabaseSetup().pipe(
      finalize(() => this.checkingDb.set(false))
    ).subscribe({
      next: (status) => {
        this.dbStatus.set(status);
        if (!status.ready) {
           console.warn('Supabase Check Failed:', status.errors);
        }
      },
      error: (err) => {
        console.error('Network Error checking DB:', err);
        this.dbStatus.set({ ready: false, errors: ['Network error. Check console for details.'] });
      }
    });
  }

  testConnection() {
    this.toast.info("Testing connection to Supabase...");
    this.api.checkDatabaseSetup().subscribe(status => {
      if (status.ready) {
        this.toast.success("Connection Successful! Tables found.");
      } else {
        this.toast.error(status.errors?.[0] || "Connection Failed");
      }
    });
  }

  handleLogin(e: Event) {
    e.preventDefault();
    if (!this.loginId || !this.password) {
      this.toast.error("Please enter both ID and password");
      return;
    }

    // Allow Bypass for Demo Credentials 'admin'/'admin'
    const isDemoBypass = this.loginId === 'admin' && this.password === 'admin';

    if (this.dbStatus() && !this.dbStatus()!.ready && !isDemoBypass) {
      this.toast.error("Database connection failed. Check your config.");
      return;
    }

    this.loading.set(true);

    if (this.loginId.toLowerCase() === 'admin' || this.loginId.includes('@')) {
      this.attemptAdminLogin();
    } else {
      this.attemptEmployeeLogin();
    }
  }

  private attemptAdminLogin() {
    this.api.adminLogin({ username: this.loginId, password: this.password }).pipe(
      finalize(() => this.loading.set(false))
    ).subscribe(data => {
      if (data.success && data.admin) {
        this.authService.login(data.admin, 'admin');
        this.toast.success("Welcome back, Admin!");
        this.router.navigate(['/admin/dashboard']);
      } else {
        this.toast.error(data.error || "Invalid admin credentials.");
      }
    });
  }

  private attemptEmployeeLogin() {
    this.api.employeeLogin({ employeeId: this.loginId, pin: this.password }).pipe(
      finalize(() => this.loading.set(false))
    ).subscribe(data => {
      if (data.success && data.employee) {
        this.authService.login(data.employee, 'employee');
        this.toast.success(`Welcome back, ${data.employee.name}!`);
        this.router.navigate(['/employee/dashboard']);
      } else {
        this.toast.error(data.error || "Invalid employee credentials.");
      }
    });
  }
}
