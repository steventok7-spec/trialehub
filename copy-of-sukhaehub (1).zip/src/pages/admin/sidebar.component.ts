
import { Component, input, output, ChangeDetectionStrategy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../components/ui/icon.component';

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  imports: [CommonModule, IconComponent],
  template: `
    <aside 
      class="bg-[#1c1917] text-stone-300 flex flex-col transition-all duration-300 ease-in-out border-r border-stone-800"
      [class.w-64]="!isCollapsed()"
      [class.w-20]="isCollapsed()"
    >
        <!-- Logo Area -->
        <div class="h-16 flex items-center shrink-0 border-b border-stone-800"
          [class.justify-center]="isCollapsed()"
          [class.px-6]="!isCollapsed()"
        >
            <div class="w-8 h-8 bg-lime-500 rounded-lg shadow-[0_0_15px_rgba(132,204,22,0.3)] flex items-center justify-center font-black text-lg shrink-0 text-stone-900 select-none">
              S
            </div>
            @if(!isCollapsed()) {
              <h2 class="text-lg font-bold text-white tracking-wide ml-3 whitespace-nowrap">SUKHA</h2>
            }
        </div>

        <!-- Navigation -->
        <nav class="flex-1 p-3 space-y-1.5 overflow-y-auto custom-scrollbar">
            @for(item of navItems; track item.id) {
                <button (click)="selectTab(item.id)" 
                    class="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-sm font-medium transition-all duration-200 group relative"
                    [class.justify-center]="isCollapsed()"
                    [class.bg-white_5]="activeTab() === item.id"
                    [class.text-lime-400]="activeTab() === item.id"
                    [class.text-stone-400]="activeTab() !== item.id"
                    [class.hover:bg-white_5]="activeTab() !== item.id"
                    [class.hover:text-stone-200]="activeTab() !== item.id"
                >
                    <div class="relative">
                      <app-icon [name]="item.icon" size="20" class="flex-shrink-0 transition-colors" [class.text-lime-400]="activeTab() === item.id"/>
                      @if(activeTab() === item.id && isCollapsed()) {
                        <div class="absolute -right-2 top-0 bottom-0 w-1 bg-lime-500 rounded-full"></div>
                      }
                    </div>
                    
                    @if(!isCollapsed()) {
                      <span class="truncate">{{ item.label }}</span>
                      @if(activeTab() === item.id) {
                         <div class="ml-auto w-1.5 h-1.5 rounded-full bg-lime-400 shadow-[0_0_8px_rgba(132,204,22,0.5)]"></div>
                      }
                    }
                    
                    <!-- Tooltip for collapsed state -->
                    @if(isCollapsed()) {
                      <div class="absolute left-14 bg-stone-800 text-white text-xs font-medium py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50 shadow-xl border border-stone-700">
                        {{ item.label }}
                      </div>
                    }
                </button>
            }
        </nav>

        <!-- Footer / Collapse Toggle -->
        <div class="p-4 border-t border-stone-800 shrink-0">
            <button 
                (click)="toggleCollapse.emit()"
                class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left text-sm font-medium transition-colors text-stone-500 hover:bg-stone-800 hover:text-stone-200 group"
                [class.justify-center]="isCollapsed()"
            >
                <app-icon [name]="toggleIcon()" size="20" class="shrink-0 transition-colors"/>
                @if(!isCollapsed()) {
                  <span>Collapse</span>
                }
            </button>
        </div>
    </aside>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    .bg-white_5 {
      background-color: rgba(255, 255, 255, 0.05);
    }
    .custom-scrollbar::-webkit-scrollbar {
      width: 4px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: transparent;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background-color: #44403c;
      border-radius: 20px;
    }
  `]
})
export class AdminSidebarComponent {
  activeTab = input.required<string>();
  isCollapsed = input(false);
  
  tabChange = output<string>();
  toggleCollapse = output<void>();

  toggleIcon = computed(() => this.isCollapsed() ? 'chevrons-right' : 'chevrons-left');

  navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
    { id: 'employees', label: 'People Directory', icon: 'users' },
    { id: 'attendance', label: 'Attendance', icon: 'clock' },
    { id: 'payroll', label: 'Payroll', icon: 'receipt' },
    { id: 'leave', label: 'Leave Requests', icon: 'calendar-days' },
    { id: 'sick', label: 'Sick Reports', icon: 'heart-pulse' },
    { id: 'claims', label: 'Expenses', icon: 'receipt' },
  ];

  selectTab(tabId: string) {
    this.tabChange.emit(tabId);
  }
}
