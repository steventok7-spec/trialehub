
import { Component } from '@angular/core';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'admin-leave',
  standalone: true,
  imports: [IconComponent],
  template: `
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden min-h-[50vh]">
      <!-- Mobile View: Empty State -->
      <div class="flex flex-col items-center justify-center h-full py-20 px-6 text-center">
         <div class="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
            <app-icon name="calendar-days" size="32" class="text-slate-300"/>
         </div>
         <h3 class="text-slate-900 font-bold text-lg mb-1">No Leave Requests</h3>
         <p class="text-slate-500 max-w-xs mx-auto">There are no pending leave requests to review at this time.</p>
      </div>
    </div>
  `
})
export class AdminLeave {}
