
import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { IconComponent } from '../../../components/ui/icon.component';
import { PayrollEntry } from '../../../models';

@Component({
  selector: 'admin-payroll',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent],
  template: `
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 min-h-[500px]">
      <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
        <div>
           <h3 class="font-bold text-xl text-gray-800">Payroll Summary</h3>
           <p class="text-sm text-gray-500">Calculate net pay based on attendance & claims</p>
        </div>
        
        <div class="flex items-center gap-3">
          <input 
            type="month" 
            [(ngModel)]="selectedMonth" 
            (change)="loadPayroll()"
            class="p-2 border border-gray-300 rounded-lg text-sm font-medium bg-gray-50"
          />
          <button (click)="exportToCsv()" class="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 text-sm flex items-center gap-2">
            <app-icon name="receipt" size="16"/>
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      @if (loading()) {
        <div class="flex flex-col items-center justify-center py-20 text-gray-400">
           <div class="w-10 h-10 border-4 border-gray-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
           <span>Calculating salaries...</span>
        </div>
      } @else if (payrollData().length > 0) {
        <div class="overflow-x-auto">
          <table class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th class="px-6 py-3">Employee</th>
                <th class="px-6 py-3">Type</th>
                <th class="px-6 py-3 text-right">Base Salary / Rate</th>
                <th class="px-6 py-3 text-right">Work Hours</th>
                <th class="px-6 py-3 text-right">Claims (Approved)</th>
                <th class="px-6 py-3 text-right font-bold text-gray-900">Net Pay</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
              @for (entry of payrollData(); track entry.employeeId) {
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 font-medium text-gray-900">{{ entry.name }}</td>
                  <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded-full text-xs font-bold"
                      [class.bg-blue-100]="entry.employmentType === 'full_time'"
                      [class.text-blue-700]="entry.employmentType === 'full_time'"
                      [class.bg-purple-100]="entry.employmentType === 'part_time'"
                      [class.text-purple-700]="entry.employmentType === 'part_time'"
                    >
                      {{ entry.employmentType === 'full_time' ? 'Full Time' : 'Part Time' }}
                    </span>
                  </td>
                  <td class="px-6 py-4 text-right font-mono">{{ entry.baseSalary | currency:'IDR':'symbol':'1.0-0' }}</td>
                  <td class="px-6 py-4 text-right font-mono">
                    {{ entry.employmentType === 'part_time' ? (entry.totalAttendanceHours | number:'1.1-1') + ' hrs' : '-' }}
                  </td>
                  <td class="px-6 py-4 text-right font-mono text-green-600">
                    +{{ entry.approvedClaims | currency:'IDR':'symbol':'1.0-0' }}
                  </td>
                  <td class="px-6 py-4 text-right font-mono font-bold text-gray-900 bg-gray-50/50">
                    {{ entry.netPay | currency:'IDR':'symbol':'1.0-0' }}
                  </td>
                </tr>
              }
            </tbody>
            <tfoot class="bg-gray-100 font-bold text-gray-900">
               <tr>
                 <td colspan="5" class="px-6 py-4 text-right">Total Payout:</td>
                 <td class="px-6 py-4 text-right">{{ totalPayout() | currency:'IDR':'symbol':'1.0-0' }}</td>
               </tr>
            </tfoot>
          </table>
        </div>
      } @else {
        <div class="text-center py-20 bg-gray-50 rounded-xl border border-dashed border-gray-300">
          <app-icon name="calendar" size="40" class="text-gray-300 mb-2 inline-block"/>
          <p class="text-gray-500">No payroll data found for this period.</p>
        </div>
      }
    </div>
  `
})
export class AdminPayrollComponent implements OnInit {
  private api = inject(ApiService);
  
  // Default to current month YYYY-MM
  selectedMonth = new Date().toISOString().slice(0, 7);
  payrollData = signal<PayrollEntry[]>([]);
  loading = signal(false);
  
  totalPayout = signal(0);

  ngOnInit() {
    this.loadPayroll();
  }

  loadPayroll() {
    this.loading.set(true);
    const [year, month] = this.selectedMonth.split('-').map(Number);
    
    this.api.generatePayroll(year, month).then(data => {
      this.payrollData.set(data);
      this.totalPayout.set(data.reduce((sum, item) => sum + item.netPay, 0));
      this.loading.set(false);
    });
  }

  exportToCsv() {
    if (this.payrollData().length === 0) return;

    const headers = ['Employee ID', 'Name', 'Type', 'Base Salary', 'Work Hours', 'Claims', 'Net Pay'];
    const rows = this.payrollData().map(p => [
      p.employeeId,
      p.name,
      p.employmentType,
      p.baseSalary,
      p.totalAttendanceHours.toFixed(2),
      p.approvedClaims,
      p.netPay
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payroll_${this.selectedMonth}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
