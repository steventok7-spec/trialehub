
import { Component } from '@angular/core';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'admin-sick',
  standalone: true,
  imports: [IconComponent],
  template: `
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden min-h-[50vh]">
      <div class="flex flex-col items-center justify-center h-full py-20 px-6 text-center">
         <div class="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-4">
            <app-icon name="heart-pulse" size="32" class="text-red-200"/>
         </div>
         <h3 class="text-slate-900 font-bold text-lg mb-1">No Sick Reports</h3>
         <p class="text-slate-500 max-w-xs mx-auto">There are no new sick leave reports submitted.</p>
      </div>
    </div>
  `
})
export class AdminSick {}
