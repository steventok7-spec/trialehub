
import { Component, OnInit, inject, signal, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../services/api.service';
import { IconComponent } from '../../../components/ui/icon.component';

interface AttendanceRecord {
  employeeName: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  hours: string | null;
  id: string; // For unique tracking
}

interface GroupedAttendance {
  date: string;
  formattedDate: string;
  records: AttendanceRecord[];
}

@Component({
  selector: 'admin-attendance',
  standalone: true,
  imports: [CommonModule, IconComponent],
  template: `
    <div class="max-w-3xl mx-auto">
      @if(loading()) {
        <div class="text-center py-20 text-slate-500">
           <div class="w-8 h-8 mx-auto border-2 border-slate-300 border-t-indigo-600 rounded-full animate-spin mb-3"></div>
           Loading records...
        </div>
      } @else {
        <div class="space-y-8">
          @for (group of groupedRecords(); track group.date) {
            <div>
              <div class="sticky top-[70px] bg-slate-50/95 backdrop-blur z-10 py-2 mb-2 border-b border-slate-100">
                 <h4 class="font-bold text-xs uppercase tracking-wider text-slate-500">{{ group.formattedDate }}</h4>
              </div>
              
              <div class="space-y-3">
                @for (record of group.records; track record.id) {
                  <div 
                    (click)="toggleExpand(record.id)"
                    class="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 cursor-pointer active:scale-[0.99] transition-all duration-200 hover:border-indigo-300 hover:shadow-md"
                    [class.ring-2]="isExpanded(record.id)"
                    [class.ring-indigo-100]="isExpanded(record.id)"
                    [class.border-indigo-400]="isExpanded(record.id)"
                  >
                    <!-- Main Row -->
                    <div class="flex items-center gap-4">
                      <!-- Avatar/Icon -->
                       <div class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors"
                            [class.bg-green-100]="!isLate(record.check_in)"
                            [class.text-green-600]="!isLate(record.check_in)"
                            [class.bg-amber-100]="isLate(record.check_in)"
                            [class.text-amber-600]="isLate(record.check_in)">
                          <span class="font-bold text-sm">{{ record.employeeName.charAt(0) }}</span>
                       </div>

                      <div class="flex-1 min-w-0">
                        <p class="font-bold text-slate-900 truncate">{{ record.employeeName }}</p>
                        <div class="flex items-center gap-3 text-sm mt-0.5">
                          <span class="font-medium text-slate-600">{{ formatTime(record.check_in) }}</span>
                           @if(record.check_out) {
                             <span class="text-slate-300">&rarr;</span>
                             <span class="text-slate-500">{{ formatTime(record.check_out) }}</span>
                           }
                        </div>
                      </div>
                      
                      @if(record.hours) {
                        <div class="text-right flex-shrink-0">
                           <span class="block font-bold text-slate-800">{{ record.hours }}h</span>
                        </div>
                       }
                    </div>

                    <!-- Details (Expandable) -->
                    <div class="grid grid-rows-[0fr] transition-[grid-template-rows] duration-300 ease-out"
                         [class.grid-rows-[1fr]]="isExpanded(record.id)">
                      <div class="overflow-hidden">
                        <div class="pt-4 mt-4 border-t border-slate-100 text-sm space-y-3">
                           <div class="flex justify-between items-center bg-slate-50 p-3 rounded-lg">
                              <span class="text-slate-500 font-medium">Status</span>
                              @if(isLate(record.check_in)) {
                                <span class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold text-amber-700 bg-amber-100 rounded-full">
                                  <app-icon name="alert-circle" size="14"/> Late Check-in
                                </span>
                              } @else {
                                <span class="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold text-green-700 bg-green-100 rounded-full">
                                  <app-icon name="check-circle" size="14"/> On Time
                                </span>
                              }
                           </div>
                           
                           <div class="grid grid-cols-2 gap-3">
                             <div class="p-3 border border-slate-100 rounded-lg">
                               <p class="text-xs text-slate-400 uppercase mb-1 font-semibold">Clock In</p>
                               <p class="font-mono font-medium text-slate-700">{{ record.check_in || '--:--' }}</p>
                             </div>
                             <div class="p-3 border border-slate-100 rounded-lg">
                               <p class="text-xs text-slate-400 uppercase mb-1 font-semibold">Clock Out</p>
                               <p class="font-mono font-medium text-slate-700">{{ record.check_out || '--:--' }}</p>
                             </div>
                           </div>
                        </div>
                      </div>
                    </div>
                  </div>
                }
              </div>
            </div>
          } @empty {
            <div class="flex flex-col items-center justify-center py-20 text-slate-400">
                <app-icon name="calendar" size="48" class="text-slate-200 mb-4"/>
                <p>No attendance records found.</p>
            </div>
          }
        </div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminAttendance implements OnInit {
  private api = inject(ApiService);
  attendanceRecords = signal<AttendanceRecord[]>([]);
  loading = signal(true);
  expandedRecordId = signal<string | null>(null);

  groupedRecords = computed<GroupedAttendance[]>(() => {
    const records = this.attendanceRecords();
    if (!records.length) return [];

    const grouped = records.reduce((acc, record) => {
      const date = record.date;
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(record);
      return acc;
    }, {} as Record<string, AttendanceRecord[]>);

    return Object.keys(grouped)
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
      .map(date => ({
        date,
        formattedDate: this.formatDateHeader(date),
        records: grouped[date]
      }));
  });

  ngOnInit() {
    this.api.getAllAttendance().subscribe(data => {
      const recordsWithIds = data.map((d, i) => ({ ...d, id: `${d.date}-${d.employeeName}-${i}` }));
      this.attendanceRecords.set(recordsWithIds);
      this.loading.set(false);
    });
  }

  toggleExpand(recordId: string) {
    this.expandedRecordId.update(current => current === recordId ? null : recordId);
  }

  isExpanded(recordId: string): boolean {
    return this.expandedRecordId() === recordId;
  }
  
  formatTime(time: string | null): string {
    if (!time) return '--:--';
    return time;
  }

  isLate(time: string | null): boolean {
      if (!time) return false;
      try {
        const [hourMinute, period] = time.split(' ');
        let [hours, minutes] = hourMinute.split(':').map(Number);
        if (period.toLowerCase() === 'pm' && hours < 12) {
            hours += 12;
        }
        if (period.toLowerCase() === 'am' && hours === 12) {
            hours = 0;
        }
        return hours > 9 || (hours === 9 && minutes > 0);
      } catch {
        return false;
      }
  }

  formatDateHeader(dateStr: string): string {
    const date = new Date(dateStr + 'T12:00:00Z');
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    
    const dateDay = date.toLocaleDateString('en-CA', {timeZone: 'UTC'});
    const todayDay = today.toLocaleDateString('en-CA');
    const yesterdayDay = yesterday.toLocaleDateString('en-CA');
    
    if (dateDay === todayDay) {
      return `Today`;
    }
    if (dateDay === yesterdayDay) {
      return `Yesterday`;
    }
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
  }
}
