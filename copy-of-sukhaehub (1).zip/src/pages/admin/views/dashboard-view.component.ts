
import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../services/api.service';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'admin-dashboard-view',
  standalone: true,
  imports: [CommonModule, IconComponent],
  template: `
    @if(loading()){
      <div class="flex flex-col items-center justify-center py-20 text-slate-400">
         <div class="w-8 h-8 border-2 border-slate-300 border-t-indigo-600 rounded-full animate-spin mb-3"></div>
         <span>Loading data...</span>
      </div>
    } @else if (summaryData()) {
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        
        <!-- Card 1 -->
        <div class="bg-white p-5 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 flex items-center gap-5 transition-transform active:scale-[0.98]">
           <div class="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <app-icon name="users" size="28" class="text-indigo-600"/>
          </div>
          <div>
            <div class="text-sm font-medium text-slate-500 mb-1">Total Employees</div>
            <div class="text-3xl font-bold text-slate-800 tracking-tight">{{ summaryData()!.totalEmployees }}</div>
          </div>
        </div>

        <!-- Card 2 -->
        <div class="bg-white p-5 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 flex items-center gap-5 transition-transform active:scale-[0.98]">
          <div class="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <app-icon name="check-circle" size="28" class="text-emerald-600"/>
          </div>
          <div>
            <div class="text-sm font-medium text-slate-500 mb-1">Present Today</div>
            <div class="text-3xl font-bold text-slate-800 tracking-tight">{{ summaryData()!.presentToday }}</div>
          </div>
        </div>

        <!-- Card 3 -->
        <div class="bg-white p-5 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 flex items-center gap-5 transition-transform active:scale-[0.98] sm:col-span-2 lg:col-span-1">
          <div class="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <app-icon name="calendar-days" size="28" class="text-amber-600"/>
          </div>
          <div>
            <div class="text-sm font-medium text-slate-500 mb-1">On Leave</div>
            <div class="text-3xl font-bold text-slate-800 tracking-tight">{{ summaryData()!.onLeave }}</div>
          </div>
        </div>
      </div>
    } @else {
       <div class="text-center p-10 text-red-500 bg-red-50 rounded-xl">Could not load dashboard data.</div>
    }
    
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 min-h-[300px] flex flex-col items-center justify-center text-slate-400">
      <app-icon name="layout-dashboard" size="48" class="text-slate-200 mb-4"/>
      <p>Activity Chart Visualization</p>
    </div>
  `
})
export class AdminDashboardView implements OnInit {
  private api = inject(ApiService);
  summaryData = signal<{ totalEmployees: number, presentToday: number, onLeave: number } | null>(null);
  loading = signal(true);

  ngOnInit() {
    this.api.getAdminSummary().subscribe(data => {
      this.summaryData.set(data);
      this.loading.set(false);
    });
  }
}
