
import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from '../../services/toast.service';
import { AuthService } from '../../auth/auth.service';
import { IconComponent } from '../../components/ui/icon.component';
import { AdminDashboardView } from './views/dashboard-view.component';
import { AdminEmployeesNew } from './views/employees-new.component';
import { AdminAttendance } from './views/attendance.component';
import { AdminLeave } from './views/leave.component';
import { AdminSick } from './views/sick.component';
import { AdminClaims } from './views/claims.component';
import { AdminPayrollComponent } from './views/payroll.component';
import { AdminSidebarComponent } from './sidebar.component';
import { Admin } from '../../models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    IconComponent, 
    AdminSidebarComponent,
    AdminDashboardView, 
    AdminEmployeesNew, 
    AdminAttendance, 
    AdminLeave, 
    AdminSick, 
    AdminClaims,
    AdminPayrollComponent
  ],
  template: `
    @if (admin) {
      <div class="h-[100dvh] w-full bg-[#fcfaf8] flex overflow-hidden">
        
        <!-- Desktop Sidebar (Fixed) -->
        <app-admin-sidebar 
          class="hidden md:flex flex-shrink-0 h-full z-30 relative border-r border-stone-200"
          [activeTab]="activeTab()" 
          [isCollapsed]="isSidebarCollapsed()"
          (tabChange)="setActiveTab($event)"
          (toggleCollapse)="toggleSidebarCollapse()"
        />

        <!-- Main Content Wrapper -->
        <div class="flex-1 flex flex-col h-full overflow-hidden relative w-full">
          
          <!-- Sticky Header -->
          <header class="bg-white/80 backdrop-blur-md border-b border-stone-200 px-6 py-4 flex items-center justify-between shrink-0 z-20 h-16 transition-all">
            <div class="flex items-center gap-3">
              <!-- Mobile Menu Button (Placeholder for now as sidebar is hidden on mobile) -->
               <div class="md:hidden w-8 h-8 bg-lime-500 rounded-lg flex items-center justify-center text-stone-900 font-black text-lg select-none shadow-sm shadow-lime-200">
                S
              </div>
              <h1 class="text-lg md:text-xl font-bold text-stone-800 tracking-tight truncate">
                {{ getPageTitle() }}
              </h1>
            </div>
            
            <div class="flex items-center gap-4">
              <div class="hidden md:block text-right">
                <p class="text-sm font-bold text-stone-900 leading-tight">{{ admin!.name }}</p>
                <p class="text-[10px] uppercase tracking-wider text-stone-500 font-bold">Administrator</p>
              </div>
              <button
                (click)="handleLogout()"
                class="p-2 text-stone-400 hover:bg-red-50 hover:text-red-600 rounded-full transition-all active:scale-95"
                title="Log out"
              >
                <app-icon name="log-out" size="20" />
              </button>
            </div>
          </header>

          <!-- Scrollable Content Area -->
          <main class="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6 lg:p-8 pb-28 md:pb-8 scroll-smooth w-full">
            <div class="max-w-7xl mx-auto w-full animate-fade-in">
              @switch (activeTab()) {
                @case ('dashboard') { <admin-dashboard-view /> }
                @case ('employees') { <admin-employees-new /> }
                @case ('attendance') { <admin-attendance /> }
                @case ('leave') { <admin-leave /> }
                @case ('sick') { <admin-sick /> }
                @case ('claims') { <admin-claims /> }
                @case ('payroll') { <admin-payroll /> }
              }
            </div>
          </main>
          
          <!-- Mobile Bottom Navigation -->
          <nav class="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-stone-200 z-50 shadow-[0_-8px_30px_rgba(0,0,0,0.04)] pb-[env(safe-area-inset-bottom)] transition-transform duration-300">
            <div class="grid grid-cols-5 h-[72px] w-full relative">
              
              <button (click)="setActiveTab('dashboard')" class="nav-item group" [class.active]="activeTab() === 'dashboard'">
                <div class="icon-container">
                   <app-icon name="layout-dashboard" [size]="24" />
                </div>
                <span class="label">Home</span>
              </button>

              <button (click)="setActiveTab('employees')" class="nav-item group" [class.active]="activeTab() === 'employees'">
                <div class="icon-container">
                  <app-icon name="users" [size]="24" />
                </div>
                <span class="label">People</span>
              </button>

              <button (click)="setActiveTab('attendance')" class="nav-item group" [class.active]="activeTab() === 'attendance'">
                 <div class="icon-container">
                  <app-icon name="clock" [size]="24" />
                 </div>
                <span class="label">Time</span>
              </button>

              <button (click)="setActiveTab('payroll')" class="nav-item group" [class.active]="activeTab() === 'payroll'">
                 <div class="icon-container">
                  <app-icon name="receipt" [size]="24" />
                 </div>
                <span class="label">Pay</span>
              </button>

              <button (click)="setActiveTab('leave')" class="nav-item group" [class.active]="activeTab() === 'leave'">
                 <div class="icon-container">
                  <app-icon name="menu" [size]="24" />
                 </div>
                <span class="label">More</span>
              </button>
              
            </div>
          </nav>
        </div>
      </div>
    } @else {
      <div class="h-screen w-full flex items-center justify-center bg-stone-50">
        <div class="flex flex-col items-center gap-4">
           <div class="w-10 h-10 border-4 border-stone-200 border-t-lime-500 rounded-full animate-spin"></div>
           <p class="text-sm text-stone-500 font-bold animate-pulse">Loading Portal...</p>
        </div>
      </div>
    }
  `,
  styles: [`
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in {
      animation: fadeIn 0.4s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
    }
    
    /* Navigation Item Base Styles */
    .nav-item {
      @apply w-full h-full flex flex-col items-center justify-center gap-1 text-stone-400 transition-all duration-300 relative select-none cursor-pointer;
      -webkit-tap-highlight-color: transparent;
    }

    /* Icon Container */
    .icon-container {
      @apply p-1.5 rounded-2xl transition-all duration-300 flex items-center justify-center relative z-10;
    }

    /* Label */
    .label {
      @apply text-[10px] font-medium leading-none tracking-wide transition-all duration-300 opacity-80;
    }

    /* Hover State */
    .nav-item:hover:not(.active) {
      @apply text-stone-600;
    }

    /* Active State Transitions */
    .nav-item.active {
      @apply text-stone-900;
    }
    
    .nav-item.active .icon-container {
      @apply bg-lime-400 text-stone-900 shadow-[0_4px_12px_rgba(132,204,22,0.4)] -translate-y-1.5 transform;
    }

    .nav-item.active .label {
      @apply font-bold text-stone-900 opacity-100 translate-y-0.5;
    }

    /* Touch Feedback */
    .nav-item:active .icon-container {
       @apply scale-90;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminDashboardComponent implements OnInit {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private toast = inject(ToastService);
  private authService = inject(AuthService);

  admin: Admin | null = null;
  activeTab = signal('dashboard');
  isSidebarCollapsed = signal(false);

  ngOnInit() {
    const user = this.authService.currentUser();
    if (user?.role === 'admin') {
      this.admin = user as Admin;
    }

    this.route.queryParams.subscribe(params => {
      const tab = params['tab'];
      if (tab) this.activeTab.set(tab);
    });

    const collapsedPref = localStorage.getItem('sidebarCollapsed');
    if (collapsedPref) {
      this.isSidebarCollapsed.set(JSON.parse(collapsedPref));
    }
  }

  toggleSidebarCollapse() {
    const newValue = !this.isSidebarCollapsed();
    this.isSidebarCollapsed.set(newValue);
    localStorage.setItem('sidebarCollapsed', JSON.stringify(newValue));
  }

  handleLogout() {
    this.authService.logout();
    this.toast.success('Logged out successfully');
  }
  
  setActiveTab(tabName: string) {
    if (this.activeTab() === tabName) return;
    this.activeTab.set(tabName);
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { tab: tabName },
      queryParamsHandling: 'merge',
    });
    // Scroll to top
    document.querySelector('main')?.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPageTitle(): string {
    const tab = this.activeTab();
    const titles: Record<string, string> = {
        'dashboard': 'Dashboard',
        'employees': 'Directory',
        'attendance': 'Attendance',
        'leave': 'Requests',
        'sick': 'Sick Reports',
        'claims': 'Expenses',
        'payroll': 'Payroll'
    };
    return titles[tab] || 'Admin Portal';
  }
}
