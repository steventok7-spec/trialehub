
import { Component, input, output, signal, OnInit, computed } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';
import { FullEmployeeDetails } from '../../../models';

@Component({
  selector: 'app-add-edit-employee-form',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <!-- Full screen overlay container -->
    <div class="fixed inset-0 z-50 overflow-y-auto bg-stone-900/40 backdrop-blur-sm" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      
      <!-- Flex container for centering/scrolling -->
      <div class="flex min-h-full items-end justify-center p-0 sm:items-center sm:p-4">
        
        <!-- Modal Panel -->
        <div class="relative transform w-full bg-[#fcfaf8] sm:rounded-2xl shadow-2xl transition-all sm:max-w-2xl flex flex-col h-[90vh] sm:h-auto sm:max-h-[90vh]">
          
          <!-- Sticky Header -->
          <div class="bg-white px-6 py-4 border-b border-stone-100 flex items-center justify-between shrink-0 rounded-t-2xl">
            <div class="flex items-center gap-3">
               <div class="w-10 h-10 rounded-full bg-lime-50 flex items-center justify-center text-lime-600">
                  <app-icon [name]="isEditMode() ? 'edit' : 'user'" size="20"/>
               </div>
               <div>
                  <h2 class="text-lg font-bold text-stone-800 leading-tight">{{ isEditMode() ? 'Edit Profile' : 'New Employee' }}</h2>
                  <p class="text-xs text-stone-500">{{ isEditMode() ? 'Update details below' : 'Fill in the details' }}</p>
               </div>
            </div>
            <button (click)="close.emit()" class="text-stone-400 hover:text-stone-600 transition-colors p-2 rounded-full hover:bg-stone-50 active:scale-95">
              <app-icon name="x-circle" size="24" />
            </button>
          </div>

          <!-- Scrollable Form Content -->
          <div class="flex-1 overflow-y-auto p-6 scroll-smooth">
            <form #employeeForm="ngForm" class="space-y-6">
              
              <!-- Section 1: Identity -->
              <div class="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm">
                <h3 class="text-xs font-bold text-stone-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                   <app-icon name="user" size="14"/> Identity
                </h3>
                <div class="space-y-4">
                  <div>
                    <label class="block text-sm font-bold text-stone-700 mb-1.5">Full Name</label>
                    <input type="text" [(ngModel)]="formData.name" name="name" required class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-lime-500 focus:border-lime-500 transition-all bg-stone-50/50 text-stone-900 placeholder-stone-400" placeholder="e.g. John Doe" />
                  </div>
                  <div>
                    <label class="block text-sm font-bold text-stone-700 mb-1.5">Email (Login ID)</label>
                    <input type="email" [(ngModel)]="formData.email" name="email" [readonly]="isEditMode()" class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-lime-500 focus:border-lime-500 transition-all disabled:bg-stone-100 disabled:text-stone-500 text-stone-900 placeholder-stone-400" placeholder="john@company.com" />
                  </div>
                </div>
              </div>

              <!-- Section 2: Job Details -->
              <div class="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm">
                <h3 class="text-xs font-bold text-stone-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                   <app-icon name="layout-dashboard" size="14"/> Job Details
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label class="block text-sm font-bold text-stone-700 mb-1.5">Job Title</label>
                    <div class="relative">
                      <select [(ngModel)]="formData.job_title" name="job_title" class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-lime-500 focus:border-lime-500 transition-all appearance-none bg-white text-stone-900">
                        <option value="commis_kitchen">Commis Kitchen</option>
                        <option value="barista">Barista</option>
                        <option value="steward">Steward</option>
                        <option value="commis_pastry">Commis Pastry</option>
                        <option value="fnb_service">F&B Service</option>
                        <option value="manager">Manager</option>
                      </select>
                      <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-stone-400">
                        <app-icon name="chevrons-up-down" size="16" />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label class="block text-sm font-bold text-stone-700 mb-1.5">Employment Type</label>
                    <div class="relative">
                      <select [(ngModel)]="formData.employment_type" name="employment_type" class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-lime-500 focus:border-lime-500 transition-all appearance-none bg-white text-stone-900">
                        <option value="full_time">Full Time</option>
                        <option value="part_time">Part Time</option>
                      </select>
                      <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-stone-400">
                         <app-icon name="chevrons-up-down" size="16" />
                      </div>
                    </div>
                  </div>
                   <div class="sm:col-span-2">
                    <label class="block text-sm font-bold text-stone-700 mb-1.5">Status</label>
                    <div class="flex items-center gap-4">
                        <label class="flex items-center gap-2 cursor-pointer p-3 border border-stone-200 rounded-xl flex-1 hover:bg-stone-50" [class.border-lime-500]="formData.status === 'active'" [class.bg-lime-50]="formData.status === 'active'">
                            <input type="radio" [(ngModel)]="formData.status" name="status" value="active" class="text-lime-600 focus:ring-lime-500">
                            <span class="font-medium text-stone-700">Active</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer p-3 border border-stone-200 rounded-xl flex-1 hover:bg-stone-50" [class.border-red-500]="formData.status === 'inactive'" [class.bg-red-50]="formData.status === 'inactive'">
                            <input type="radio" [(ngModel)]="formData.status" name="status" value="inactive" class="text-red-600 focus:ring-red-500">
                            <span class="font-medium text-stone-700">Inactive</span>
                        </label>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Section 3: Payroll (Admin Only) -->
              <div class="bg-red-50/30 p-5 rounded-2xl border border-red-100">
                <h3 class="text-xs font-bold text-red-600 uppercase tracking-wider mb-4 flex items-center gap-2">
                   <app-icon name="lock" size="14"/> Payroll Data (Confidential)
                </h3>
                <div class="space-y-4">
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label class="block text-sm font-bold text-stone-700 mb-1.5">Bank Name</label>
                        <div class="relative">
                          <select [(ngModel)]="formData.bank_name" name="bank_name" class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all appearance-none bg-white text-stone-900">
                            <option value="">Select Bank</option>
                            <option value="bca">BCA</option>
                            <option value="mandiri">Mandiri</option>
                            <option value="bni">BNI</option>
                            <option value="bri">BRI</option>
                            <option value="cimb">CIMB Niaga</option>
                            <option value="danamon">Danamon</option>
                            <option value="permata">Permata</option>
                            <option value="other">Other</option>
                          </select>
                           <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-stone-400">
                             <app-icon name="chevrons-up-down" size="16" />
                          </div>
                        </div>
                      </div>
                      <div>
                        <label class="block text-sm font-bold text-stone-700 mb-1.5">Account Number</label>
                        <input type="text" [(ngModel)]="formData.bank_account_number" name="bank_account_number" pattern="[0-9]*" class="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all text-stone-900" placeholder="Digits only"/>
                      </div>
                  </div>
                  
                  @if (formData.employment_type === 'full_time') {
                    <div>
                      <label class="block text-sm font-bold text-stone-700 mb-1.5">Monthly Salary (IDR)</label>
                      <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-stone-500 font-bold">Rp</span>
                        <input type="number" [(ngModel)]="formData.monthly_salary_idr" name="monthly_salary_idr" class="w-full pl-11 pr-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all font-mono font-medium text-stone-900" placeholder="0" />
                      </div>
                    </div>
                  }
                  
                  @if (formData.employment_type === 'part_time') {
                    <div>
                      <label class="block text-sm font-bold text-stone-700 mb-1.5">Hourly Rate (IDR)</label>
                      <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-stone-500 font-bold">Rp</span>
                        <input type="number" [(ngModel)]="formData.hourly_rate_idr" name="hourly_rate_idr" class="w-full pl-11 pr-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all font-mono font-medium text-stone-900" placeholder="0" />
                      </div>
                    </div>
                  }
                </div>
              </div>

            </form>
          </div>

          <!-- Sticky Footer Actions -->
          <div class="p-6 border-t border-stone-100 bg-white rounded-b-2xl shrink-0 flex flex-col sm:flex-row justify-end gap-3">
            <button type="button" (click)="close.emit()" class="w-full sm:w-auto px-6 py-3.5 bg-white border border-stone-300 text-stone-700 rounded-xl font-bold hover:bg-stone-50 active:bg-stone-100 transition-all">
              Cancel
            </button>
            <button type="button" (click)="onSubmit(employeeForm)" [disabled]="loading()" class="w-full sm:w-auto px-8 py-3.5 bg-lime-500 text-stone-900 rounded-xl font-bold hover:bg-lime-400 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_12px_rgba(132,204,22,0.4)] transition-all flex items-center justify-center gap-2">
              @if (loading()) {
                <div class="w-5 h-5 border-2 border-stone-900 border-t-transparent rounded-full animate-spin"></div>
                <span>Saving...</span>
              } @else {
                <span>Save Profile</span>
              }
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AddEditEmployeeFormComponent implements OnInit {
  employeeData = input<FullEmployeeDetails | null>(null);
  close = output<void>();
  save = output<FullEmployeeDetails>();

  loading = signal(false);
  
  formData: Partial<FullEmployeeDetails> = {
    name: '', 
    email: '', 
    job_title: 'commis_kitchen', 
    employment_type: 'full_time',
    status: 'active',
    bank_name: undefined,
    bank_account_number: '',
    monthly_salary_idr: 0,
    hourly_rate_idr: 0
  };

  isEditMode = computed(() => !!this.employeeData());

  ngOnInit() {
    if (this.isEditMode()) {
      this.formData = { ...this.employeeData()! };
    }
  }

  onSubmit(form: NgForm) {
    if (form.invalid) {
      Object.keys(form.controls).forEach(key => {
        form.controls[key].markAsTouched();
      });
      return;
    }
    this.loading.set(true);
    this.save.emit(this.formData as FullEmployeeDetails);
  }
}
