
import { Component, input, output, signal, OnInit, ChangeDetectionStrategy, HostListener } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';
import { Employee } from '../../../models';

@Component({
  selector: 'app-schedule-employee-modal',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
      <div class="fixed inset-0 bg-gray-900/50 backdrop-blur-sm transition-opacity" (click)="close.emit()"></div>

      <div class="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 w-full max-w-md border border-gray-100">
          
          <div class="bg-white px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h2 class="text-xl font-bold text-gray-800">Weekly Schedule</h2>
              <p class="text-sm text-gray-500">{{ employee().name }}</p>
            </div>
            <button (click)="close.emit()" class="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-100">
              <app-icon name="x-circle" size="24" />
            </button>
          </div>

          <div class="px-6 py-6">
            <form #scheduleForm="ngForm" (submit)="onSave()">
              <div class="space-y-3">
                @for(day of days; track day.key) {
                  <label 
                    [for]="day.key" 
                    class="flex items-center justify-between w-full p-4 border rounded-xl cursor-pointer transition-all hover:bg-gray-50"
                    [class.bg-indigo-50]="schedule[day.key]"
                    [class.border-indigo-200]="schedule[day.key]"
                    [class.border-gray-200]="!schedule[day.key]"
                  >
                    <span class="font-medium text-gray-800">{{ day.fullName }}</span>
                    <div class="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" [name]="day.key" [id]="day.key" [(ngModel)]="schedule[day.key]" class="sr-only peer">
                      <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </div>
                  </label>
                }
              </div>
              
              <div class="pt-6 mt-2 flex justify-end gap-3">
                <button type="button" (click)="close.emit()" class="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">Cancel</button>
                <button type="submit" [disabled]="loading()" class="px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-indigo-200 transition-colors">
                  @if (loading()) {
                    <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Saving...</span>
                  } @else {
                    Save Schedule
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ScheduleEmployeeModalComponent implements OnInit {
  employee = input.required<Employee>();
  close = output<void>();
  save = output<{ employeeId: string, schedule: any }>();

  loading = signal(false);
  schedule: any = {};
  
  days = [
    { key: 'mon', label: 'Mon', fullName: 'Monday' },
    { key: 'tue', label: 'Tue', fullName: 'Tuesday' },
    { key: 'wed', label: 'Wed', fullName: 'Wednesday' },
    { key: 'thu', label: 'Thu', fullName: 'Thursday' },
    { key: 'fri', label: 'Fri', fullName: 'Friday' },
    { key: 'sat', label: 'Sat', fullName: 'Saturday' },
    { key: 'sun', label: 'Sun', fullName: 'Sunday' }
  ];

  @HostListener('document:keydown.escape')
  onEscapeKey() {
    this.close.emit();
  }

  ngOnInit() {
    this.schedule = { ...this.employee().schedule };
  }

  onSave() {
    this.loading.set(true);
    this.save.emit({ employeeId: this.employee().id, schedule: this.schedule });
  }
}
