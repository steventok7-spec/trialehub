
import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { ToastService } from '../../services/toast.service';
import { AuthService } from '../../auth/auth.service';
import { IconComponent } from '../../components/ui/icon.component';
import { LeaveRequestFormComponent } from './modals/leave-request-form.component';
import { SickReportFormComponent } from './modals/sick-report-form.component';
import { ExpenseClaimFormComponent } from './modals/expense-claim-form.component';
import { Attendance, EmployeeHistory, EmployeeSummary } from '../../models';

@Component({
  selector: 'app-employee-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    IconComponent, 
    LeaveRequestFormComponent,
    SickReportFormComponent,
    ExpenseClaimFormComponent
  ],
  template: `
    <div class="h-[100dvh] w-full bg-[#fcfaf8] flex flex-col overflow-hidden relative">
      <!-- Fixed Header -->
      <header class="bg-white/90 backdrop-blur-sm border-b border-stone-200 px-6 py-4 z-20 shrink-0">
        <div class="max-w-md mx-auto w-full flex items-center justify-between">
          @switch (activeTab()) {
            @case ('home') {
              <div>
                <h1 class="text-xl font-black text-stone-900 tracking-tight">Hi, {{ getFirstName() }}!</h1>
                <p class="text-xs text-stone-500 font-medium uppercase tracking-wide">{{ formatDate() }}</p>
              </div>
            }
            @case ('history') {
               <h1 class="text-xl font-black text-stone-900 tracking-tight">History</h1>
            }
            @case ('profile') {
               <h1 class="text-xl font-black text-stone-900 tracking-tight">My Profile</h1>
            }
          }
          
          <div class="w-10 h-10 rounded-full bg-lime-100 flex items-center justify-center text-lime-700 font-bold border border-lime-200 shadow-sm">
             {{ getInitial() }}
          </div>
        </div>
      </header>

      <!-- Scrollable Main Content -->
      <main class="flex-1 overflow-y-auto overflow-x-hidden pb-24 pt-6 px-4 scroll-smooth w-full">
        <div class="max-w-md mx-auto w-full space-y-6 pb-6">
          @switch (activeTab()) {
            @case ('home') {
              <div class="animate-fade-in space-y-6">
                <!-- Location Prompt -->
                @if (locationPermission() === 'prompt') {
                  <div class="bg-amber-50 rounded-2xl p-4 border border-amber-200 shadow-sm">
                    <div class="flex items-start gap-3">
                      <div class="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 text-amber-600">
                        <app-icon name="map-pin" size="16" />
                      </div>
                      <div>
                        <h4 class="text-sm font-bold text-amber-900 mb-1">Enable Location</h4>
                        <p class="text-xs text-amber-800 leading-relaxed">Location access is required to verify you are at the office for check-in.</p>
                      </div>
                    </div>
                  </div>
                }

                <!-- Check In/Out Grid -->
                <div class="grid grid-cols-2 gap-4">
                  <button
                    (click)="handleCheckIn()"
                    [disabled]="loading() || (todayAttendance() && todayAttendance()!.check_in)"
                    class="bg-white h-44 rounded-3xl p-4 flex flex-col items-center justify-center gap-3 border border-stone-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:border-lime-300 transition-all active:scale-95 disabled:opacity-50 disabled:scale-100 relative overflow-hidden group"
                  >
                    <div class="absolute inset-0 bg-gradient-to-br from-lime-50/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div class="w-16 h-16 bg-lime-100 rounded-2xl flex items-center justify-center text-lime-600 shadow-inner relative z-10">
                      <app-icon name="check-circle" size="32" />
                    </div>
                    <div class="text-center relative z-10">
                      <p class="font-bold text-stone-900 text-lg">Check In</p>
                      @if (todayAttendance()?.check_in) {
                        <p class="text-xs text-lime-700 font-bold mt-1 bg-lime-100 px-2 py-0.5 rounded-full">{{ formatTime(todayAttendance()!.check_in) }}</p>
                      } @else {
                        <p class="text-xs text-stone-400 mt-1">Start your day</p>
                      }
                    </div>
                  </button>

                  <button
                    (click)="handleCheckOut()"
                    [disabled]="loading() || !todayAttendance()?.check_in || todayAttendance()?.check_out"
                    class="bg-white h-44 rounded-3xl p-4 flex flex-col items-center justify-center gap-3 border border-stone-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:border-red-200 transition-all active:scale-95 disabled:opacity-50 disabled:scale-100 relative overflow-hidden group"
                  >
                     <div class="absolute inset-0 bg-gradient-to-br from-red-50/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                     <div class="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center text-red-500 shadow-inner relative z-10">
                      <app-icon name="x-circle" size="32" />
                    </div>
                    <div class="text-center relative z-10">
                      <p class="font-bold text-stone-900 text-lg">Check Out</p>
                       @if (todayAttendance()?.check_out) {
                        <p class="text-xs text-red-600 font-bold mt-1 bg-red-50 px-2 py-0.5 rounded-full">{{ formatTime(todayAttendance()!.check_out) }}</p>
                      } @else {
                         <p class="text-xs text-stone-400 mt-1">End your shift</p>
                      }
                    </div>
                  </button>
                </div>

                <!-- Summary Cards -->
                @if(summaryData()) {
                  <div class="bg-white rounded-3xl p-6 shadow-sm border border-stone-100">
                    <div class="grid grid-cols-3 divide-x divide-stone-100">
                      <div class="text-center px-2">
                        <p class="text-2xl font-black text-stone-800">{{ summaryData()!.leaveDaysAvailable }}</p>
                        <p class="text-[10px] font-bold text-stone-400 uppercase tracking-wider mt-1">Leave Bal</p>
                      </div>
                      <div class="text-center px-2">
                        <p class="text-2xl font-black text-stone-800">{{ summaryData()!.sickDaysTaken }}</p>
                        <p class="text-[10px] font-bold text-stone-400 uppercase tracking-wider mt-1">Sick Days</p>
                      </div>
                      <div class="text-center px-2">
                        <p class="text-2xl font-black text-stone-800">{{ summaryData()!.pendingClaims }}</p>
                        <p class="text-[10px] font-bold text-stone-400 uppercase tracking-wider mt-1">Pending</p>
                      </div>
                    </div>
                  </div>
                }
                
                <!-- Quick Actions -->
                <div class="space-y-3">
                   <h3 class="text-sm font-bold text-stone-900 px-1 uppercase tracking-wide opacity-70">Quick Actions</h3>
                   <button (click)="showLeaveRequestForm.set(true)" class="w-full bg-white p-4 rounded-2xl flex items-center gap-4 shadow-sm border border-stone-100 active:scale-98 transition-transform group">
                      <div class="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 group-hover:bg-indigo-100 transition-colors">
                         <app-icon name="calendar" size="22"/>
                      </div>
                      <div class="flex-1 text-left">
                         <p class="font-bold text-stone-800 text-sm">Request Leave</p>
                         <p class="text-xs text-stone-500 mt-0.5">Vacation, Personal time off</p>
                      </div>
                      <app-icon name="chevrons-right" size="18" class="text-stone-300"/>
                   </button>
                   
                   <button (click)="showSickReportForm.set(true)" class="w-full bg-white p-4 rounded-2xl flex items-center gap-4 shadow-sm border border-stone-100 active:scale-98 transition-transform group">
                      <div class="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center text-red-600 group-hover:bg-red-100 transition-colors">
                         <app-icon name="heart-pulse" size="22"/>
                      </div>
                      <div class="flex-1 text-left">
                         <p class="font-bold text-stone-800 text-sm">Report Sick</p>
                         <p class="text-xs text-stone-500 mt-0.5">Notify admin of absence</p>
                      </div>
                      <app-icon name="chevrons-right" size="18" class="text-stone-300"/>
                   </button>
                   
                   <button (click)="showExpenseClaimForm.set(true)" class="w-full bg-white p-4 rounded-2xl flex items-center gap-4 shadow-sm border border-stone-100 active:scale-98 transition-transform group">
                      <div class="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 group-hover:bg-amber-100 transition-colors">
                         <app-icon name="receipt" size="22"/>
                      </div>
                      <div class="flex-1 text-left">
                         <p class="font-bold text-stone-800 text-sm">Expense Claim</p>
                         <p class="text-xs text-stone-500 mt-0.5">Submit receipts for refund</p>
                      </div>
                      <app-icon name="chevrons-right" size="18" class="text-stone-300"/>
                   </button>
                </div>
              </div>
            }

            @case ('history') {
              <div class="animate-fade-in space-y-4">
                 @for (record of history(); track $index) {
                   <div class="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm">
                      <div class="flex justify-between items-center mb-4">
                         <span class="font-bold text-stone-800">{{ record.date }}</span>
                         <span class="text-[10px] font-bold text-stone-500 bg-stone-50 px-2 py-1 rounded-md uppercase tracking-wider">{{ getDayName(record.date) }}</span>
                      </div>
                      <div class="flex items-center gap-4 text-center">
                         <div class="flex-1">
                            <p class="text-[10px] text-stone-400 font-bold uppercase mb-1">In</p>
                            <p class="font-mono font-bold text-stone-800">{{ formatTime(record.check_in) || '--:--' }}</p>
                         </div>
                         <div class="w-px h-8 bg-stone-100"></div>
                         <div class="flex-1">
                            <p class="text-[10px] text-stone-400 font-bold uppercase mb-1">Out</p>
                            <p class="font-mono font-bold text-stone-800">{{ formatTime(record.check_out) || '--:--' }}</p>
                         </div>
                         <div class="w-px h-8 bg-stone-100"></div>
                         <div class="flex-1">
                            <p class="text-[10px] text-stone-400 font-bold uppercase mb-1">Hrs</p>
                            <p class="font-mono font-bold text-lime-600">{{ record.hours || '-' }}</p>
                         </div>
                      </div>
                   </div>
                 } @empty {
                   <div class="flex flex-col items-center justify-center py-20 text-stone-400">
                      <app-icon name="calendar" size="48" class="text-stone-200 mb-4"/>
                      <p>No history available</p>
                   </div>
                 }
              </div>
            }

            @case ('profile') {
              <div class="animate-fade-in space-y-6">
                 <div class="bg-white rounded-3xl p-8 border border-stone-100 shadow-sm text-center">
                    <div class="w-24 h-24 mx-auto bg-stone-100 rounded-full flex items-center justify-center text-3xl font-bold text-stone-500 mb-4 border border-stone-200 shadow-inner">
                      {{ getInitial() }}
                    </div>
                    <h2 class="text-2xl font-bold text-stone-900">{{ employee.name }}</h2>
                    <p class="text-stone-500 font-medium">{{ employee.role }}</p>
                    <p class="text-sm text-stone-400 mt-1">{{ employee.email }}</p>
                 </div>
                 
                 <button (click)="handleLogout()" class="w-full bg-white p-5 rounded-2xl flex items-center justify-center gap-2 text-red-600 font-bold border border-stone-100 shadow-sm active:bg-red-50 transition-colors">
                    <app-icon name="log-out" size="20"/>
                    Log Out
                 </button>
              </div>
            }
          }
        </div>
      </main>

      <!-- Bottom Nav (Fixed Position Reset) -->
      <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200 z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.03)] pb-[env(safe-area-inset-bottom)]">
         <div class="grid grid-cols-3 h-[65px] max-w-md mx-auto">
            
            <button (click)="activeTab.set('home')" class="nav-item" [class.active]="activeTab() === 'home'">
               <div class="icon-container">
                  <app-icon name="layout-dashboard" size="24"/>
               </div>
               <span class="label">Home</span>
            </button>
            
            <button (click)="activeTab.set('history')" class="nav-item" [class.active]="activeTab() === 'history'">
               <div class="icon-container">
                  <app-icon name="clock" size="24"/>
               </div>
               <span class="label">History</span>
            </button>
            
            <button (click)="activeTab.set('profile')" class="nav-item" [class.active]="activeTab() === 'profile'">
               <div class="icon-container">
                  <app-icon name="user" size="24"/>
               </div>
               <span class="label">Profile</span>
            </button>

         </div>
      </nav>
    </div>

    <!-- Modals -->
    @if(showLeaveRequestForm()) {
      <app-leave-request-form 
        [employeeId]="employee.id" 
        (close)="showLeaveRequestForm.set(false)"
        (submitRequest)="handleLeaveRequest($event)"
      />
    }
    @if(showSickReportForm()) {
      <app-sick-report-form
        [employeeId]="employee.id" 
        (close)="showSickReportForm.set(false)"
        (submitRequest)="handleSickReport($event)"
      />
    }
    @if(showExpenseClaimForm()) {
      <app-expense-claim-form
        [employeeId]="employee.id" 
        (close)="showExpenseClaimForm.set(false)"
        (submitRequest)="handleExpenseClaim($event)"
      />
    }
  `,
  styles: [`
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in {
      animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    
    /* Strict Flex Centering */
    .nav-item {
       @apply w-full h-full flex flex-col items-center justify-center gap-1 transition-colors duration-200 active:bg-stone-50 text-stone-400;
    }
    
    .icon-container {
      @apply p-1.5 rounded-xl transition-all duration-200 flex items-center justify-center;
    }
    
    .label {
      @apply text-[10px] font-medium leading-none transition-all duration-200;
    }

    /* Active State */
    .nav-item.active {
       @apply text-stone-900;
    }
    
    .nav-item.active .icon-container {
       @apply bg-lime-400 text-stone-900 shadow-sm shadow-lime-200;
    }

    .nav-item.active .label {
       @apply font-bold text-stone-900;
    }
  `]
})
export class EmployeeDashboardComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  private authService = inject(AuthService);

  private readonly OFFICE_LAT = 0.5031383484339234;
  private readonly OFFICE_LON = 101.43880598650681;
  private readonly MAX_DISTANCE_METERS = 100;

  employee: any = this.authService.currentUser();
  activeTab = signal<'home' | 'history' | 'profile'>('home');
  
  todayAttendance = signal<Attendance | null>(null);
  history = signal<any[]>([]);
  loading = signal(false);
  locationPermission = signal<string | null>(null);
  summaryData = signal<EmployeeSummary | null>(null);

  showLeaveRequestForm = signal(false);
  showSickReportForm = signal(false);
  showExpenseClaimForm = signal(false);

  ngOnInit() {
    this.checkLocationPermission();
    this.loadData();
  }

  getFirstName() {
    return this.employee?.name?.split(' ')[0] || 'User';
  }

  getInitial() {
    return this.employee?.name?.charAt(0) || 'U';
  }

  async checkLocationPermission() {
    if (!navigator.geolocation) return;
    try {
      if (navigator.permissions) {
        const result = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
        this.locationPermission.set(result.state);
        result.onchange = () => this.locationPermission.set(result.state);
      }
      navigator.geolocation.getCurrentPosition(
        () => this.locationPermission.set('granted'),
        (err) => console.log('Location permission error', err)
      );
    } catch (e) { console.log(e); }
  }

  loadData() {
    if (!this.employee) return;
    this.api.getEmployeeHistory(this.employee.id).subscribe((data: EmployeeHistory) => {
        const today = new Date().toLocaleDateString('en-CA');
        const todayRecord = data.attendance.find((att: any) => att.date === today);
        this.todayAttendance.set(todayRecord || null);
        this.summaryData.set(data.summary || null);
        this.history.set([...data.attendance].reverse());
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  handleCheckIn() {
    this.loading.set(true);
    if (!navigator.geolocation) {
        this.toast.error("Geolocation is not supported by your browser.");
        this.loading.set(false);
        return;
    }
    navigator.geolocation.getCurrentPosition(
        (pos) => {
            const { latitude, longitude } = pos.coords;
            const distance = this.calculateDistance(latitude, longitude, this.OFFICE_LAT, this.OFFICE_LON);

            if (distance > this.MAX_DISTANCE_METERS) {
              this.toast.error(`You are too far from the office to check in (${distance.toFixed(0)}m away).`);
              this.loading.set(false);
              return;
            }

            this.api.checkIn({ employeeId: this.employee.id, latitude, longitude }).subscribe((res) => {
                if (res.success) {
                    this.toast.success("Checked in successfully!");
                    this.loadData();
                } else {
                    this.toast.error(res.error || "Check-in failed.");
                }
                this.loading.set(false);
            });
        },
        (err) => {
            this.toast.error("Could not get location. Please enable location services.");
            this.loading.set(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  handleCheckOut() {
    this.loading.set(true);
    this.api.checkOut({ employeeId: this.employee.id }).subscribe((res) => {
        if (res.success) {
            this.toast.success(`Checked out! Hours: ${res.hours}`);
            this.loadData();
        } else {
            this.toast.error("Check-out failed");
        }
        this.loading.set(false);
    });
  }

  handleLeaveRequest(data: any) {
    this.api.submitLeaveRequest(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Leave request submitted successfully!");
        this.showLeaveRequestForm.set(false);
      }
    });
  }

  handleSickReport(data: any) {
    this.api.submitSickReport(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Sick report submitted successfully!");
        this.showSickReportForm.set(false);
      }
    });
  }

  handleExpenseClaim(data: any) {
    this.api.submitExpenseClaim(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Expense claim submitted successfully!");
        this.showExpenseClaimForm.set(false);
      }
    });
  }
  
  handleLogout() {
    this.authService.logout();
    this.toast.success('Logged out successfully');
  }

  formatTime(iso: string | null) {
    if (!iso) return '';
    try {
        return new Date(iso).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } catch { return iso; }
  }

  formatDate() {
    return new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
  
  getDayName(dateStr: string) {
     return new Date(dateStr).toLocaleDateString('en-US', { weekday: 'long' });
  }
}
