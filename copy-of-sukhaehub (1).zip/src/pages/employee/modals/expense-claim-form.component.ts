
import { Component, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'app-expense-claim-form',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 z-50 overflow-y-auto">
      <div class="fixed inset-0 bg-gray-900/50 backdrop-blur-sm transition-opacity" (click)="close.emit()"></div>

      <div class="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
        <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 w-full max-w-md border border-gray-100">
          
          <div class="bg-white px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="text-xl font-bold text-gray-800">Submit Expense Claim</h2>
            <button (click)="close.emit()" class="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-100">
              <app-icon name="x-circle" size="24" />
            </button>
          </div>

          <div class="px-6 py-6">
            <form (submit)="onSubmit($event)" class="space-y-4">
              <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Date of Expense</label>
                <input type="date" [(ngModel)]="formData.date" name="date" required class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"/>
              </div>
              <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Amount</label>
                <div class="relative">
                  <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 font-bold">$</span>
                  <input type="number" [(ngModel)]="formData.amount" name="amount" step="0.01" placeholder="0.00" required class="w-full pl-8 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"/>
                </div>
              </div>
              <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Description</label>
                <textarea [(ngModel)]="formData.description" name="description" rows="3" required class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500" placeholder="Details about expense..."></textarea>
              </div>
              
              <div class="pt-4 flex justify-end gap-3">
                <button type="button" (click)="close.emit()" class="px-5 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">Cancel</button>
                <button type="submit" [disabled]="loading()" class="px-5 py-2.5 bg-amber-500 text-white rounded-xl font-medium hover:bg-amber-600 disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-amber-200 transition-colors">
                  @if (loading()) {
                    <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Submitting...</span>
                  } @else {
                    Submit Claim
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ExpenseClaimFormComponent {
  employeeId = input.required<string>();
  close = output<void>();
  submitRequest = output<any>();

  loading = signal(false);
  formData = {
    date: new Date().toISOString().split('T')[0],
    amount: null,
    description: ''
  };

  onSubmit(event: Event) {
    event.preventDefault();
    if (!this.formData.date || !this.formData.amount || !this.formData.description) {
      return;
    }
    this.loading.set(true);
    this.submitRequest.emit({
      employeeId: this.employeeId(),
      ...this.formData
    });
  }
}
