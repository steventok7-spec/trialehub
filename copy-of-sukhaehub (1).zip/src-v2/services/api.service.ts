import { inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs';
import { Admin, Employee, EmployeeHistory } from '../models';

// Removed @Injectable to prevent DI conflicts
export class ApiService {
  private http: HttpClient = inject(HttpClient);
  
  // NOTE: In a real app, these should come from environment files
  projectId = 'your-project-id';
  publicAnonKey = 'your-anon-key';
  
  useMock = true;

  private mockAttendance: any[] = [];
  private mockEmployees: Employee[] = [
    { id: '101', name: 'John Doe', role: 'Developer', email: 'john.doe@example.com', salary: 80000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '102', name: 'Jane Smith', role: 'Designer', email: 'jane.smith@example.com', salary: 75000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '103', name: 'Robert Johnson', role: 'Manager', email: 'robert.j@example.com', salary: 95000, schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false } },
    { id: '104', name: 'Emily White', role: 'QA Tester', email: 'emily.w@example.com', salary: 65000, schedule: { mon: true, tue: false, wed: true, thu: true, fri: true, sat: false, sun: false } },
  ];

  constructor() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    this.mockAttendance = [
      { 
        date: yesterday.toLocaleDateString('en-CA'), 
        check_in: new Date(yesterday.setHours(9, 0, 0, 0)).toISOString(), 
        check_out: new Date(yesterday.setHours(17, 30, 0, 0)).toISOString(), 
        hours: '8.5' 
      }
    ];
  }

  get baseUrl() {
    return `https://${this.projectId}.supabase.co/functions/v1/make-server-5188af6b`;
  }

  private get headers() {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.publicAnonKey}`,
      'Content-Type': 'application/json'
    });
  }

  private mockDelay<T>(data: T, ms = 500): Observable<T> {
    return of(data).pipe(delay(ms));
  }

  checkDatabaseSetup(): Observable<{ ready: boolean; errors?: string[] }> {
    if (this.useMock) return this.mockDelay({ ready: true });
    return this.http.get<{ ready: boolean; errors?: string[] }>(`${this.baseUrl}/setup/check`, { headers: this.headers });
  }

  adminLogin(loginData: any): Observable<{ success: boolean; admin?: Admin; error?: string }> {
    if (this.useMock) {
      if (loginData.username === 'admin' && loginData.password === 'admin') {
        return this.mockDelay({
          success: true,
          admin: { username: 'admin', role: 'manager', name: 'Admin User' }
        });
      }
      return this.mockDelay({ success: false, error: 'Invalid admin credentials' });
    }
    return this.http.post<{ success: boolean; admin?: Admin; error?: string }>(`${this.baseUrl}/admin/login`, loginData, { headers: this.headers });
  }

  employeeLogin(loginData: any): Observable<{ success: boolean; employee?: Employee; error?: string }> {
    if (this.useMock) {
       const employee = this.mockEmployees.find(e => e.id === loginData.employeeId);
       if (employee && loginData.pin === '1234') {
         return this.mockDelay({
           success: true,
           employee: employee
         });
       }
       return this.mockDelay({ success: false, error: 'Invalid employee credentials' });
    }
    return this.http.post<{ success: boolean; employee?: Employee; error?: string }>(`${this.baseUrl}/employee/login`, loginData, { headers: this.headers });
  }

  getEmployeeHistory(employeeId: string): Observable<EmployeeHistory> {
    if (this.useMock) {
      return this.mockDelay({
        attendance: [...this.mockAttendance],
        summary: {
            leaveDaysAvailable: 15,
            sickDaysTaken: 2,
            pendingClaims: 1
        }
      });
    }
    return this.http.get<EmployeeHistory>(`${this.baseUrl}/employee/${employeeId}/history`, { headers: this.headers });
  }

  getEmployeeDetails(employeeId: string): Observable<any> {
    if (this.useMock) {
      const employee = this.mockEmployees.find(e => e.id === employeeId);
      const mockData = {
        details: employee,
        attendance: [
          { date: '2024-07-29', check_in: '08:55 AM', check_out: '05:30 PM', hours: 8.6 },
          { date: '2024-07-28', check_in: '09:05 AM', check_out: '05:35 PM', hours: 8.5 }
        ],
        leave: [
          { from: '2024-08-10', to: '2024-08-15', reason: 'Vacation', status: 'Approved' }
        ],
        claims: [
          { date: '2024-07-20', amount: '$75.00', description: 'Team Dinner', status: 'Reimbursed' }
        ]
      };
      return this.mockDelay(mockData);
    }
    return this.http.get<any>(`${this.baseUrl}/admin/employee/${employeeId}`, { headers: this.headers });
  }

  getEmployees(): Observable<Employee[]> {
    if (this.useMock) {
        return this.mockDelay([...this.mockEmployees]);
    }
    return this.http.get<Employee[]>(`${this.baseUrl}/admin/employees`, { headers: this.headers });
  }

  addEmployee(employeeData: any): Observable<{ success: boolean; employee?: Employee; error?: string }> {
      if (this.useMock) {
          const newEmployee: Employee = {
              id: (Math.max(...this.mockEmployees.map(e => parseInt(e.id))) + 1).toString(),
              ...employeeData,
              schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: false, sun: false }
          };
          this.mockEmployees.push(newEmployee);
          return this.mockDelay({ success: true, employee: newEmployee });
      }
      return this.http.post<{ success: boolean; employee?: Employee; error?: string }>(`${this.baseUrl}/admin/employees`, employeeData, { headers: this.headers });
  }

  updateEmployee(employeeData: Employee): Observable<{ success: boolean; employee?: Employee; error?: string }> {
      if (this.useMock) {
          const index = this.mockEmployees.findIndex(e => e.id === employeeData.id);
          if (index !== -1) {
              this.mockEmployees[index] = { ...this.mockEmployees[index], ...employeeData };
              return this.mockDelay({ success: true, employee: this.mockEmployees[index] });
          }
          return this.mockDelay({ success: false, error: 'Employee not found' });
      }
      return this.http.put<{ success: boolean; employee?: Employee; error?: string }>(`${this.baseUrl}/admin/employees/${employeeData.id}`, employeeData, { headers: this.headers });
  }

  deleteEmployee(employeeId: string): Observable<{ success: boolean; error?: string }> {
    if (this.useMock) {
      this.mockEmployees = this.mockEmployees.filter(e => e.id !== employeeId);
      return this.mockDelay({ success: true });
    }
    return this.http.delete<{ success: boolean; error?: string }>(`${this.baseUrl}/admin/employees/${employeeId}`, { headers: this.headers });
  }

  updateSchedule(data: { employeeId: string, schedule: any }): Observable<{ success: boolean; error?: string }> {
      if (this.useMock) {
          const index = this.mockEmployees.findIndex(e => e.id === data.employeeId);
          if (index !== -1) {
              this.mockEmployees[index].schedule = data.schedule;
              return this.mockDelay({ success: true });
          }
          return this.mockDelay({ success: false, error: 'Employee not found' });
      }
      return this.http.post<{ success: boolean; error?: string }>(`${this.baseUrl}/admin/employees/${data.employeeId}/schedule`, data.schedule, { headers: this.headers });
  }

  checkIn(data: any): Observable<{ success: boolean; error?: string }> {
    if (this.useMock) {
      const todayStr = new Date().toLocaleDateString('en-CA');
      const now = new Date();
      const existing = this.mockAttendance.find(a => a.date === todayStr);
      if (!existing) {
        this.mockAttendance.push({ date: todayStr, check_in: now.toISOString(), check_out: null, hours: null });
      }
      return this.mockDelay({ success: true });
    }
    return this.http.post<{ success: boolean; error?: string }>(`${this.baseUrl}/attendance/checkin`, data, { headers: this.headers });
  }

  checkOut(data: any): Observable<{ success: boolean; hours?: string; error?: string }> {
    if (this.useMock) {
      const todayStr = new Date().toLocaleDateString('en-CA');
      const now = new Date();
      const existing = this.mockAttendance.find(a => a.date === todayStr);
      if (existing) {
        existing.check_out = now.toISOString();
        const start = new Date(existing.check_in);
        const hours = (now.getTime() - start.getTime()) / (1000 * 60 * 60);
        existing.hours = hours.toFixed(2);
        return this.mockDelay({ success: true, hours: existing.hours });
      }
      return this.mockDelay({ success: false, error: "No check-in found for today" });
    }
    return this.http.post<{ success: boolean; hours?: string; error?: string }>(`${this.baseUrl}/attendance/checkout`, data, { headers: this.headers });
  }

  submitLeaveRequest(data: any): Observable<{ success: boolean }> {
    if (this.useMock) return this.mockDelay({ success: true });
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/leave`, data, { headers: this.headers });
  }

  submitSickReport(data: any): Observable<{ success: boolean }> {
    if (this.useMock) return this.mockDelay({ success: true });
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/sick`, data, { headers: this.headers });
  }

  submitExpenseClaim(data: any): Observable<{ success: boolean }> {
    if (this.useMock) return this.mockDelay({ success: true });
    return this.http.post<{ success: boolean }>(`${this.baseUrl}/requests/claim`, data, { headers: this.headers });
  }

  // Admin specific mock data
  getAdminSummary(): Observable<{ totalEmployees: number, presentToday: number, onLeave: number }> {
    return this.mockDelay({
      totalEmployees: this.mockEmployees.length,
      presentToday: this.mockEmployees.length - 2,
      onLeave: 2
    });
  }

  getAllAttendance(): Observable<any[]> {
    const data = [
      { employeeName: 'John Doe', date: '2024-07-29', check_in: '08:55 AM', check_out: '05:30 PM', hours: 8.6 },
      { employeeName: 'Jane Smith', date: '2024-07-29', check_in: '09:15 AM', check_out: '06:00 PM', hours: 8.8 },
    ];
    return this.mockDelay(data);
  }
}
