import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../../src/services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      @for (toast of toastService.toasts(); track toast.id) {
        <div
          class="min-w-[300px] p-4 rounded-lg shadow-lg text-sm font-medium transition-all transform animate-slide-up"
          [class.bg-white]="true"
          [class.text-red-600]="toast.type === 'error'"
          [class.text-green-600]="toast.type === 'success'"
          [class.text-gray-800]="toast.type === 'info'"
          [style.border-left]="toast.type === 'error' ? '4px solid #ef4444' : toast.type === 'success' ? '4px solid #22c55e' : '4px solid #3b82f6'"
        >
          {{ toast.message }}
        </div>
      }
    </div>
  `,
  styles: [`
    @keyframes slide-up {
      from { transform: translateY(100%); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .animate-slide-up {
      animation: slide-up 0.3s ease-out;
    }
  `]
})
export class ToastComponent {
  toastService = inject(ToastService);
}
