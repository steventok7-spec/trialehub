import { Component, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'app-leave-request-form',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 bg-black/30 z-40" (click)="close.emit()"></div>
    <div class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-xl p-6 sm:p-8 w-[90vw] max-w-md z-50">
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-bold text-gray-800">Request Leave</h2>
        <button (click)="close.emit()" class="text-gray-400 hover:text-gray-600">
          <app-icon name="x-circle" />
        </button>
      </div>
      <form (submit)="onSubmit($event)" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
          <input type="date" [(ngModel)]="formData.fromDate" name="fromDate" required class="w-full p-2 border border-gray-300 rounded-lg"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
          <input type="date" [(ngModel)]="formData.toDate" name="toDate" required class="w-full p-2 border border-gray-300 rounded-lg"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Reason</label>
          <textarea [(ngModel)]="formData.reason" name="reason" rows="3" required class="w-full p-2 border border-gray-300 rounded-lg"></textarea>
        </div>
        <div class="pt-4 flex justify-end gap-3">
          <button type="button" (click)="close.emit()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
          <button type="submit" [disabled]="loading()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2">
            @if (loading()) {
              <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Submitting...</span>
            } @else {
              Submit Request
            }
          </button>
        </div>
      </form>
    </div>
  `
})
export class LeaveRequestFormComponent {
  employeeId = input.required<string>();
  close = output<void>();
  submitRequest = output<any>();

  loading = signal(false);
  formData = {
    fromDate: '',
    toDate: '',
    reason: ''
  };

  onSubmit(event: Event) {
    event.preventDefault();
    this.loading.set(true);
    if (!this.formData.fromDate || !this.formData.toDate || !this.formData.reason) {
      this.loading.set(false);
      return;
    }
    this.submitRequest.emit({
      employeeId: this.employeeId(),
      ...this.formData
    });
  }
}