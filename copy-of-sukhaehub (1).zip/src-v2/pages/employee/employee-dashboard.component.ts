import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService } from '../../../src/services/api.service';
import { ToastService } from '../../../src/services/toast.service';
// FIX: Corrected import path for AuthService to point to `src` directory.
import { AuthService } from '../../../src/auth/auth.service';
import { IconComponent } from '../../components/ui/icon.component';
import { LeaveRequestFormComponent } from './modals/leave-request-form.component';
import { SickReportFormComponent } from './modals/sick-report-form.component';
import { ExpenseClaimFormComponent } from './modals/expense-claim-form.component';
import { Attendance, EmployeeHistory, EmployeeSummary } from '../../models';

@Component({
  selector: 'app-employee-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    IconComponent, 
    LeaveRequestFormComponent,
    SickReportFormComponent,
    ExpenseClaimFormComponent
  ],
  template: `
    <div class="bg-[#f8f9fb] min-h-screen">
      <!-- Header -->
      <div class="bg-white px-4 sm:px-6 py-6 border-b border-[#e5e7eb]">
        <div class="flex items-center justify-between mb-1">
          <h1 class="text-xl font-bold text-[#1a1d29]">Hi, {{ getFirstName() }}! 👋</h1>
           <div class="flex items-center gap-4">
            <button (click)="handleLogout()" class="text-gray-500 hover:text-red-600" title="Log out">
              <app-icon name="log-out" size="20"/>
            </button>
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-sm font-bold">
              {{ getInitial() }}
            </div>
          </div>
        </div>
        <p class="text-sm text-[#6b7280]">{{ formatDate() }}</p>
      </div>

      <div class="p-4 sm:p-6 space-y-4">
        
        <!-- Location Permission Pending -->
        @if (locationPermission() === 'prompt') {
          <div class="bg-gradient-to-r from-[#fef3c7] to-[#fde68a] rounded-2xl p-4 sm:p-5 border-2 border-[#f59e0b]">
            <div class="flex items-start gap-3">
              <div class="w-10 h-10 bg-[#f59e0b] rounded-full flex items-center justify-center flex-shrink-0">
                <app-icon name="map-pin" class="w-5 h-5 text-white" />
              </div>
              <div class="flex-1">
                <h4 class="text-sm font-bold text-[#78350f] mb-1">📍 Enable Location Tracking</h4>
                <p class="text-xs text-[#713f12] mb-2">
                  To check in, you must be at the office. Click "Check In" to share your location for verification.
                </p>
              </div>
            </div>
          </div>
        }

        <!-- Check In/Out Buttons -->
        <div class="grid grid-cols-2 gap-3">
          <button
            (click)="handleCheckIn()"
            [disabled]="loading() || (todayAttendance() && todayAttendance()!.check_in)"
            class="bg-white rounded-2xl p-4 sm:p-6 flex flex-col items-center justify-center gap-2 sm:gap-3 border-2 border-transparent hover:border-[#22c55e] disabled:opacity-40 disabled:hover:border-transparent transition-all active:scale-95"
          >
            <div class="w-10 h-10 sm:w-12 sm:h-12 bg-[#dcfce7] rounded-full flex items-center justify-center">
              <app-icon name="check-circle" class="w-5 h-5 sm:w-6 sm:h-6 text-[#22c55e]" />
            </div>
            <div class="text-center">
              <p class="text-xs sm:text-sm font-semibold text-[#1a1d29] mb-1">Check In</p>
              @if (todayAttendance() && todayAttendance()!.check_in) {
                  <p class="text-base sm:text-lg font-bold text-[#1a1d29]">{{ formatTime(todayAttendance()!.check_in) }}</p>
                  @if (isLateCheckIn()) {
                    <div class="flex items-center justify-center gap-1 mt-1">
                      <app-icon name="alert-circle" class="w-3 h-3 text-[#ef4444]" />
                      <p class="text-xs text-[#ef4444] font-medium">Late</p>
                    </div>
                  } @else {
                    <p class="text-xs text-[#22c55e]">On-time • +100 pt</p>
                  }
              }
            </div>
          </button>

          <button
            (click)="handleCheckOut()"
            [disabled]="loading() || !todayAttendance() || !todayAttendance()!.check_in || todayAttendance()!.check_out"
            class="bg-white rounded-2xl p-4 sm:p-6 flex flex-col items-center justify-center gap-2 sm:gap-3 border-2 border-transparent hover:border-[#f87171] disabled:opacity-40 disabled:hover:border-transparent transition-all active:scale-95"
          >
            <div class="w-10 h-10 sm:w-12 sm:h-12 bg-[#fee2e2] rounded-full flex items-center justify-center">
              <app-icon name="x-circle" class="w-5 h-5 sm:w-6 sm:h-6 text-[#ef4444]" />
            </div>
            <div class="text-center">
              <p class="text-xs sm:text-sm font-semibold text-[#1a1d29] mb-1">Check Out</p>
              @if (todayAttendance() && todayAttendance()!.check_out) {
                  <p class="text-base sm:text-lg font-bold text-[#1a1d29]">{{ formatTime(todayAttendance()!.check_out) }}</p>
                  @if (isEarlyCheckOut()) {
                    <div class="flex items-center justify-center gap-1 mt-1">
                      <app-icon name="alert-circle" class="w-3 h-3 text-[#f59e0b]" />
                      <p class="text-xs text-[#f59e0b] font-medium">Early</p>
                    </div>
                  } @else {
                    <p class="text-xs text-[#6b7280]">Go-home</p>
                  }
              }
            </div>
          </button>
        </div>

        <!-- Summary -->
        @if(summaryData()) {
          <div class="bg-white rounded-2xl p-4 sm:p-5">
            <h3 class="text-base font-bold text-[#1a1d29] mb-4">My Summary</h3>
            <div class="grid grid-cols-3 gap-3 text-center">
              <div>
                <p class="text-2xl font-bold text-indigo-600">{{ summaryData()!.leaveDaysAvailable }}</p>
                <p class="text-xs text-gray-500">Leave Days</p>
              </div>
              <div>
                <p class="text-2xl font-bold text-red-600">{{ summaryData()!.sickDaysTaken }}</p>
                <p class="text-xs text-gray-500">Sick Days Taken</p>
              </div>
              <div>
                <p class="text-2xl font-bold text-amber-500">{{ summaryData()!.pendingClaims }}</p>
                <p class="text-xs text-gray-500">Pending Claims</p>
              </div>
            </div>
          </div>
        }

        <!-- Time Off Quick Actions -->
        <div class="bg-white rounded-2xl p-4 sm:p-5">
          <h3 class="text-base font-bold text-[#1a1d29] mb-4">Quick Actions</h3>
          <div class="space-y-3">
            <button
              (click)="showLeaveRequestForm.set(true)"
              class="w-full bg-[#f8f9fb] hover:bg-[#f0f2f5] rounded-xl p-3 sm:p-4 flex items-center gap-3 transition-colors active:scale-98"
            >
              <div class="w-10 h-10 bg-[#ddd6fe] rounded-lg flex items-center justify-center flex-shrink-0">
                <app-icon name="calendar" class="w-5 h-5 text-[#8b5cf6]" />
              </div>
              <div class="flex-1 text-left">
                <p class="text-sm font-semibold text-[#1a1d29]">Request Leave</p>
                <p class="text-xs text-[#6b7280]">Submit time off request</p>
              </div>
            </button>

            <button
              (click)="showSickReportForm.set(true)"
              class="w-full bg-[#f8f9fb] hover:bg-[#f0f2f5] rounded-xl p-3 sm:p-4 flex items-center gap-3 transition-colors active:scale-98"
            >
              <div class="w-10 h-10 bg-[#fecaca] rounded-lg flex items-center justify-center flex-shrink-0">
                <app-icon name="heart-pulse" class="w-5 h-5 text-[#ef4444]" />
              </div>
              <div class="flex-1 text-left">
                <p class="text-sm font-semibold text-[#1a1d29]">Report Sick</p>
                <p class="text-xs text-[#6b7280]">Submit sick leave</p>
              </div>
            </button>

            <button
              (click)="showExpenseClaimForm.set(true)"
              class="w-full bg-[#f8f9fb] hover:bg-[#f0f2f5] rounded-xl p-3 sm:p-4 flex items-center gap-3 transition-colors active:scale-98"
            >
              <div class="w-10 h-10 bg-[#fef3c7] rounded-lg flex items-center justify-center flex-shrink-0">
                <app-icon name="receipt" class="w-5 h-5 text-[#f59e0b]" />
              </div>
              <div class="flex-1 text-left">
                <p class="text-sm font-semibold text-[#1a1d29]">Expense Claim</p>
                <p class="text-xs text-[#6b7280]">Submit reimbursement</p>
              </div>
            </button>
          </div>
        </div>

        <!-- Recent Activity -->
        @if (recentActivity().length > 0) {
          <div class="bg-white rounded-2xl p-6">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-base font-bold text-[#1a1d29]">Recent Activity</h3>
            </div>

            <div class="space-y-4">
              @for (activity of recentActivity(); track $index) {
                <div class="flex items-center gap-4">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center"
                       [class.bg-[#dcfce7]]="activity.type === 'checkin'"
                       [class.bg-[#fee2e2]]="activity.type === 'checkout'"
                       [class.bg-[#fef3c7]]="activity.type === 'overtime'">
                    @if (activity.type === 'checkin') { <app-icon name="check-circle" class="w-5 h-5 text-[#22c55e]" /> }
                    @if (activity.type === 'checkout') { <app-icon name="x-circle" class="w-5 h-5 text-[#ef4444]" /> }
                    @if (activity.type === 'overtime') { <app-icon name="clock" class="w-5 h-5 text-[#f59e0b]" /> }
                  </div>
                  <div class="flex-1">
                    <p class="text-sm font-semibold text-[#1a1d29]">
                      @if(activity.type === 'checkin') { Check In } 
                      @else if(activity.type === 'checkout') { Check Out }
                      @else { Overtime }
                    </p>
                    <p class="text-xs text-[#6b7280]">{{ activity.date }}</p>
                  </div>
                  <div class="text-right">
                    <p class="text-sm font-bold text-[#1a1d29]">{{ formatTime(activity.time) }}</p>
                    @if (activity.hours) {
                      <p class="text-xs text-[#6b7280]">
                         {{ activity.type === 'overtime' ? activity.hours : activity.hours + ' hr' }}
                      </p>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>
    </div>

    <!-- Modals -->
    @if(showLeaveRequestForm()) {
      <app-leave-request-form 
        [employeeId]="employee.id" 
        (close)="showLeaveRequestForm.set(false)"
        (submitRequest)="handleLeaveRequest($event)"
      />
    }
    @if(showSickReportForm()) {
      <app-sick-report-form
        [employeeId]="employee.id" 
        (close)="showSickReportForm.set(false)"
        (submitRequest)="handleSickReport($event)"
      />
    }
    @if(showExpenseClaimForm()) {
      <app-expense-claim-form
        [employeeId]="employee.id" 
        (close)="showExpenseClaimForm.set(false)"
        (submitRequest)="handleExpenseClaim($event)"
      />
    }
  `
})
export class EmployeeDashboardComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  private authService = inject(AuthService);

  private readonly OFFICE_LAT = 0.5031383484339234;
  private readonly OFFICE_LON = 101.43880598650681;
  private readonly MAX_DISTANCE_METERS = 100; // 100 meters radius

  employee: any = this.authService.currentUser();
  todayAttendance = signal<Attendance | null>(null);
  recentActivity = signal<any[]>([]);
  loading = signal(false);
  locationPermission = signal<string | null>(null);
  summaryData = signal<EmployeeSummary | null>(null);

  showLeaveRequestForm = signal(false);
  showSickReportForm = signal(false);
  showExpenseClaimForm = signal(false);

  ngOnInit() {
    this.checkLocationPermission();
    this.loadTodayAttendance();
  }

  getFirstName() {
    return this.employee?.name?.split(' ')[0] || 'User';
  }

  getInitial() {
    return this.employee?.name?.charAt(0) || 'U';
  }

  async checkLocationPermission() {
    if (!navigator.geolocation) return;
    try {
      if (navigator.permissions) {
        const result = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
        this.locationPermission.set(result.state);
        result.onchange = () => this.locationPermission.set(result.state);
      }
      navigator.geolocation.getCurrentPosition(
        () => this.locationPermission.set('granted'),
        (err) => console.log('Loc error', err)
      );
    } catch (e) { console.log(e); }
  }

  loadTodayAttendance() {
    if (!this.employee) return;
    this.api.getEmployeeHistory(this.employee.id).subscribe((data: EmployeeHistory) => {
        const today = new Date().toLocaleDateString('en-CA');
        const todayRecord = data.attendance.find((att: any) => att.date === today);
        this.todayAttendance.set(todayRecord || null);
        this.summaryData.set(data.summary || null);

        const activities: any[] = [];
        const records = [...data.attendance].reverse();
        
        records.slice(0, 3).forEach((rec: any) => {
            if (rec.check_out) {
                activities.push({ type: 'checkout', time: rec.check_out, date: rec.date, hours: rec.hours });
            }
            if (rec.check_in) {
                activities.push({ type: 'checkin', time: rec.check_in, date: rec.date });
            }
        });
        
        this.recentActivity.set(activities);
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // in metres
  }

  handleCheckIn() {
    this.loading.set(true);
    if (!navigator.geolocation) {
        this.toast.error("Geolocation is not supported by your browser.");
        this.loading.set(false);
        return;
    }
    navigator.geolocation.getCurrentPosition(
        (pos) => {
            const { latitude, longitude } = pos.coords;
            const distance = this.calculateDistance(latitude, longitude, this.OFFICE_LAT, this.OFFICE_LON);

            if (distance > this.MAX_DISTANCE_METERS) {
              this.toast.error(`You are too far from the office to check in (${distance.toFixed(0)}m away).`);
              this.loading.set(false);
              return;
            }

            this.api.checkIn({ employeeId: this.employee.id, latitude, longitude }).subscribe((res) => {
                if (res.success) {
                    this.toast.success("Checked in successfully!");
                    this.loadTodayAttendance();
                } else {
                    this.toast.error(res.error || "Check-in failed.");
                }
                this.loading.set(false);
            });
        },
        (err) => {
            this.toast.error("Could not get location. Please enable location services.");
            this.loading.set(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  handleCheckOut() {
    this.loading.set(true);
    this.api.checkOut({ employeeId: this.employee.id }).subscribe((res) => {
        if (res.success) {
            this.toast.success(`Checked out! Hours: ${res.hours}`);
            this.loadTodayAttendance();
        } else {
            this.toast.error("Check-out failed");
        }
        this.loading.set(false);
    });
  }

  handleLeaveRequest(data: any) {
    this.api.submitLeaveRequest(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Leave request submitted successfully!");
        this.showLeaveRequestForm.set(false);
      }
    });
  }

  handleSickReport(data: any) {
    this.api.submitSickReport(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Sick report submitted successfully!");
        this.showSickReportForm.set(false);
      }
    });
  }

  handleExpenseClaim(data: any) {
    this.api.submitExpenseClaim(data).subscribe((res) => {
      if (res.success) {
        this.toast.success("Expense claim submitted successfully!");
        this.showExpenseClaimForm.set(false);
      }
    });
  }
  
  handleLogout() {
    this.authService.logout();
    this.toast.success('Logged out successfully');
  }

  formatTime(iso: string | null) {
    if (!iso) return '';
    try {
        return new Date(iso).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } catch { return iso; }
  }

  formatDate() {
    return new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }

  isLateCheckIn() {
    const rec = this.todayAttendance();
    if (!rec?.check_in) return false;
    const d = new Date(rec.check_in);
    return d.getHours() > 9 || (d.getHours() === 9 && d.getMinutes() > 0);
  }

  isEarlyCheckOut() {
    const rec = this.todayAttendance();
    if (!rec?.check_out) return false;
    const d = new Date(rec.check_out);
    return d.getHours() < 18;
  }
}
