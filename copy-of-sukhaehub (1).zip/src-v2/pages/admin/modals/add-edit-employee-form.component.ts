import { Component, input, output, signal, OnInit, computed } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'app-add-edit-employee-form',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 bg-black/40 z-40" (click)="close.emit()"></div>
    <div class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-xl p-6 sm:p-8 w-[90vw] max-w-lg z-50">
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-bold text-gray-800">{{ isEditMode() ? 'Edit Employee' : 'Add New Employee' }}</h2>
        <button (click)="close.emit()" class="text-gray-400 hover:text-gray-600">
          <app-icon name="x-circle" />
        </button>
      </div>
      <form #employeeForm="ngForm" (submit)="onSubmit(employeeForm)" class="space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input type="text" [(ngModel)]="formData.name" name="name" required #name="ngModel" class="w-full p-2 border rounded-lg" [class.border-red-500]="name.invalid && name.touched" [class.border-gray-300]="name.valid || name.pristine"/>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" [(ngModel)]="formData.email" name="email" required email #email="ngModel" class="w-full p-2 border rounded-lg" [class.border-red-500]="email.invalid && email.touched" [class.border-gray-300]="email.valid || email.pristine"/>
          </div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Role / Position</label>
            <input type="text" [(ngModel)]="formData.role" name="role" required #role="ngModel" class="w-full p-2 border rounded-lg" [class.border-red-500]="role.invalid && role.touched" [class.border-gray-300]="role.valid || role.pristine"/>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Salary</label>
            <div class="relative">
              <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">$</span>
              <input type="number" [(ngModel)]="formData.salary" name="salary" placeholder="e.g., 80000" required #salary="ngModel" class="w-full p-2 pl-7 border rounded-lg" [class.border-red-500]="salary.invalid && salary.touched" [class.border-gray-300]="salary.valid || salary.pristine"/>
            </div>
          </div>
        </div>
        <div class="pt-4 flex justify-end gap-3">
          <button type="button" (click)="close.emit()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
          <button type="submit" [disabled]="employeeForm.invalid || loading()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2">
            @if (loading()) {
              <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Saving...</span>
            } @else {
              Save Employee
            }
          </button>
        </div>
      </form>
    </div>
  `
})
export class AddEditEmployeeFormComponent implements OnInit {
  employeeData = input<any | null>(null);
  close = output<void>();
  save = output<any>();

  loading = signal(false);
  formData: any = { name: '', email: '', role: '', salary: null };

  isEditMode = computed(() => !!this.employeeData());

  ngOnInit() {
    if (this.isEditMode()) {
      this.formData = { ...this.employeeData() };
    }
  }

  onSubmit(form: NgForm) {
    if (form.invalid) {
      // FIX: Use Object.keys to iterate over form controls and mark them as touched. This resolves the 'unknown' type error.
      Object.keys(form.controls).forEach(field => {
        form.controls[field].markAsTouched();
      });
      return;
    }
    this.loading.set(true);
    this.save.emit(this.formData);
  }
}