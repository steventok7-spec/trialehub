import { Component, input, output, signal, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'app-schedule-employee-modal',
  standalone: true,
  imports: [FormsModule, CommonModule, IconComponent],
  template: `
    <div class="fixed inset-0 bg-black/40 z-40" (click)="close.emit()"></div>
    <div class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-xl p-6 sm:p-8 w-[90vw] max-w-md z-50 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h2 class="text-xl font-bold text-gray-800">Set Weekly Schedule</h2>
          <p class="text-sm text-gray-500">{{ employee().name }}</p>
        </div>
        <button (click)="close.emit()" class="text-gray-400 hover:text-gray-600 rounded-full p-1">
          <app-icon name="x-circle" />
        </button>
      </div>
      <form #scheduleForm="ngForm" (submit)="onSave()">
        <div class="space-y-3">
          @for(day of days; track day.key) {
            <label 
              [for]="day.key" 
              class="flex items-center justify-between w-full p-4 border rounded-lg cursor-pointer transition-colors"
              [class.bg-indigo-50]="schedule[day.key]"
              [class.border-indigo-200]="schedule[day.key]"
            >
              <span class="font-medium text-gray-800">{{ day.fullName }}</span>
              <div class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" [name]="day.key" [id]="day.key" [(ngModel)]="schedule[day.key]" class="sr-only peer">
                <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
              </div>
            </label>
          }
        </div>
        <div class="pt-6 flex justify-end gap-3">
          <button type="button" (click)="close.emit()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
          <button type="submit" [disabled]="loading()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2">
            @if (loading()) {
              <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Saving...</span>
            } @else {
              Save Schedule
            }
          </button>
        </div>
      </form>
    </div>
  `
})
export class ScheduleEmployeeModalComponent implements OnInit {
  employee = input.required<any>();
  close = output<void>();
  save = output<{ employeeId: string, schedule: any }>();

  loading = signal(false);
  schedule: any = {};
  
  days = [
    { key: 'mon', label: 'Mon', fullName: 'Monday' },
    { key: 'tue', label: 'Tue', fullName: 'Tuesday' },
    { key: 'wed', label: 'Wed', fullName: 'Wednesday' },
    { key: 'thu', label: 'Thu', fullName: 'Thursday' },
    { key: 'fri', label: 'Fri', fullName: 'Friday' },
    { key: 'sat', label: 'Sat', fullName: 'Saturday' },
    { key: 'sun', label: 'Sun', fullName: 'Sunday' }
  ];

  ngOnInit() {
    this.schedule = { ...this.employee().schedule };
  }

  onSave() {
    this.loading.set(true);
    this.save.emit({ employeeId: this.employee().id, schedule: this.schedule });
  }
}