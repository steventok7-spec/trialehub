import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from '../../../src/services/toast.service';
import { IconComponent } from '../../components/ui/icon.component';
import { AdminDashboardView } from './views/dashboard-view.component';
import { AdminEmployeesNew } from './views/employees-new.component';
import { AdminAttendance } from './views/attendance.component';
import { AdminLeave } from './views/leave.component';
import { AdminSick } from './views/sick.component';
import { AdminClaims } from './views/claims.component';
// FIX: Corrected import path for AuthService to point to `src` directory.
import { AuthService } from '../../../src/auth/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    IconComponent, 
    AdminDashboardView, 
    AdminEmployeesNew, 
    AdminAttendance, 
    AdminLeave, 
    AdminSick, 
    AdminClaims
  ],
  template: `
  @if (!admin) {
    <div class="min-h-screen flex items-center justify-center">Loading...</div>
  } @else {
    <div class="min-h-screen bg-[#f8f9fb] flex flex-col">
      <!-- Header -->
      <header class="bg-white border-b border-[#e5e7eb] p-6 sticky top-0 z-10">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 class="text-xl font-bold text-[#1a1d29]">
              Management Portal
            </h1>
            <p class="text-sm text-[#6b7280]">
              {{ admin.username }} • Manager
            </p>
          </div>
          <button
            (click)="handleLogout()"
            class="px-4 py-2 bg-[#fee2e2] text-[#ef4444] rounded-xl hover:bg-[#fecaca] transition-colors font-medium text-sm"
          >
            Log out
          </button>
        </div>
      </header>

      <main class="flex-1 p-6 pb-20 max-w-7xl mx-auto w-full">
        <!-- Custom Tabs Implementation -->
        <div class="w-full">
          <!-- Tab List -->
          <div class="grid w-full grid-cols-6 mb-6 h-auto p-1 bg-white border border-[#e5e7eb] rounded-xl gap-1">
            <button (click)="setActiveTab('dashboard')" [class]="getTabClass('dashboard')">
              <app-icon name="layout-dashboard" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[10px]">Dashboard</span>
            </button>

            <button (click)="setActiveTab('employees')" [class]="getTabClass('employees')">
              <app-icon name="users" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[10px]">Employees</span>
            </button>

            <button (click)="setActiveTab('attendance')" [class]="getTabClass('attendance')">
              <app-icon name="clock" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[10px]">Attendance</span>
            </button>

            <button (click)="setActiveTab('leave')" [class]="getTabClass('leave')">
              <app-icon name="calendar-days" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[11px]">Leave</span>
            </button>

            <button (click)="setActiveTab('sick')" [class]="getTabClass('sick')">
              <app-icon name="heart-pulse" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[11px]">Sick</span>
            </button>

            <button (click)="setActiveTab('claims')" [class]="getTabClass('claims')">
              <app-icon name="receipt" class="w-5 h-5 mb-1" />
              <span class="font-medium text-[11px]">Claims</span>
            </button>
          </div>

          <!-- Tab Content -->
          <div class="mt-4">
            @switch (activeTab()) {
              @case ('dashboard') { <admin-dashboard-view /> }
              @case ('employees') { <admin-employees-new /> }
              @case ('attendance') { <admin-attendance /> }
              @case ('leave') { <admin-leave /> }
              @case ('sick') { <admin-sick /> }
              @case ('claims') { <admin-claims /> }
            }
          </div>
        </div>
      </main>
    </div>
  }
`,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminDashboardComponent implements OnInit {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private toast = inject(ToastService);
  private authService = inject(AuthService);

  admin: any = null;
  activeTab = signal('dashboard');

  ngOnInit() {
    const user = this.authService.currentUser();
    if (user?.role === 'admin') {
      this.admin = user;
    }

    this.route.queryParams.subscribe(params => {
      const tab = params['tab'];
      if (tab && ['dashboard', 'employees', 'attendance', 'leave', 'sick', 'claims'].includes(tab)) {
        this.activeTab.set(tab);
      }
    });
  }

  handleLogout() {
    this.authService.logout();
    this.toast.success('Logged out successfully');
  }
  
  setActiveTab(tabName: string) {
    this.activeTab.set(tabName);
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { tab: tabName },
      queryParamsHandling: 'merge',
    });
  }

  getTabClass(tabName: string): string {
    const baseClasses = 'flex flex-col items-center py-3 rounded-lg transition-all';
    if (this.activeTab() === tabName) {
      return `${baseClasses} bg-[#2d3142] text-white`;
    }
    return `${baseClasses} text-gray-600 hover:bg-gray-100`;
  }
}
