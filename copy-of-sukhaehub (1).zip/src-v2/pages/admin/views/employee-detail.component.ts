import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../../../src/services/api.service';
import { IconComponent } from '../../../components/ui/icon.component';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, IconComponent],
  template: `
    <div class="min-h-screen bg-[#f8f9fb] p-6">
      <div class="max-w-4xl mx-auto">
        <a routerLink="/admin/dashboard" [queryParams]="{ tab: 'employees' }" class="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 mb-4">
          &larr; Back to Directory
        </a>
        
        @if (employeeData()) {
          <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <!-- Header -->
            <div class="flex items-center gap-4 mb-6">
              <div class="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold">
                {{ employeeData().details.name.charAt(0) }}
              </div>
              <div>
                <h1 class="text-2xl font-bold text-gray-800">{{ employeeData().details.name }}</h1>
                <p class="text-gray-500">{{ employeeData().details.role }}</p>
              </div>
            </div>

            <!-- Info Grid -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-8">
              <div class="bg-gray-50 p-3 rounded-lg">
                <div class="font-semibold text-gray-600">Employee ID</div>
                <div class="text-gray-800">{{ employeeData().details.id }}</div>
              </div>
              <div class="bg-gray-50 p-3 rounded-lg">
                <div class="font-semibold text-gray-600">Email</div>
                <div class="text-gray-800">{{ employeeData().details.email }}</div>
              </div>
            </div>

            <!-- Tabs -->
            <div class="border-b border-gray-200">
              <nav class="-mb-px flex space-x-6" aria-label="Tabs">
                <button (click)="activeTab.set('attendance')"
                   [class]="getTabClass('attendance')">
                  Attendance
                </button>
                <button (click)="activeTab.set('leave')"
                   [class]="getTabClass('leave')">
                  Leave
                </button>
                <button (click)="activeTab.set('claims')"
                   [class]="getTabClass('claims')">
                  Claims
                </button>
              </nav>
            </div>
            
            <!-- Tab Content -->
            <div class="py-6">
               @switch (activeTab()) {
                @case ('attendance') {
                  <table class="w-full text-sm text-left">
                    <thead class="text-xs text-gray-500 uppercase bg-gray-50">
                      <tr>
                        <th class="px-4 py-2">Date</th>
                        <th class="px-4 py-2">Check In</th>
                        <th class="px-4 py-2">Check Out</th>
                        <th class="px-4 py-2">Hours</th>
                      </tr>
                    </thead>
                    <tbody>
                      @for(item of employeeData().attendance; track item.date) {
                        <tr class="border-b">
                          <td class="px-4 py-3">{{ item.date }}</td>
                          <td class="px-4 py-3">{{ item.check_in }}</td>
                          <td class="px-4 py-3">{{ item.check_out }}</td>
                          <td class="px-4 py-3">{{ item.hours }}</td>
                        </tr>
                      } @empty {
                        <tr><td colspan="4" class="text-center p-6 text-gray-400">No attendance data.</td></tr>
                      }
                    </tbody>
                  </table>
                }
                @case ('leave') {
                  <table class="w-full text-sm text-left">
                     <thead class="text-xs text-gray-500 uppercase bg-gray-50">
                      <tr>
                        <th class="px-4 py-2">From</th>
                        <th class="px-4 py-2">To</th>
                        <th class="px-4 py-2">Reason</th>
                        <th class="px-4 py-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                       @for(item of employeeData().leave; track item.from) {
                        <tr class="border-b">
                          <td class="px-4 py-3">{{ item.from }}</td>
                          <td class="px-4 py-3">{{ item.to }}</td>
                          <td class="px-4 py-3">{{ item.reason }}</td>
                          <td class="px-4 py-3"><span class="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">{{ item.status }}</span></td>
                        </tr>
                      } @empty {
                         <tr><td colspan="4" class="text-center p-6 text-gray-400">No leave data.</td></tr>
                      }
                    </tbody>
                  </table>
                }
                @case ('claims') {
                  <table class="w-full text-sm text-left">
                     <thead class="text-xs text-gray-500 uppercase bg-gray-50">
                      <tr>
                        <th class="px-4 py-2">Date</th>
                        <th class="px-4 py-2">Amount</th>
                        <th class="px-4 py-2">Description</th>
                        <th class="px-4 py-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                       @for(item of employeeData().claims; track item.date) {
                        <tr class="border-b">
                          <td class="px-4 py-3">{{ item.date }}</td>
                          <td class="px-4 py-3">{{ item.amount }}</td>
                          <td class="px-4 py-3">{{ item.description }}</td>
                          <td class="px-4 py-3"><span class="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">{{ item.status }}</span></td>
                        </tr>
                      } @empty {
                         <tr><td colspan="4" class="text-center p-6 text-gray-400">No claims data.</td></tr>
                      }
                    </tbody>
                  </table>
                }
              }
            </div>
          </div>
        } @else {
          <div class="text-center p-10">Loading employee data...</div>
        }
      </div>
    </div>
  `
})
export class EmployeeDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  
  employeeId: string | null = null;
  employeeData = signal<any>(null);
  activeTab = signal('attendance');

  ngOnInit() {
    this.employeeId = this.route.snapshot.paramMap.get('id');
    if (this.employeeId) {
      this.api.getEmployeeDetails(this.employeeId).subscribe(data => {
        this.employeeData.set(data);
      });
    }
  }

  getTabClass(tabName: string): string {
    const base = 'py-4 px-1 border-b-2 font-medium text-sm transition-colors';
    if (this.activeTab() === tabName) {
      return `${base} border-indigo-500 text-indigo-600`;
    }
    return `${base} border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700`;
  }
}
