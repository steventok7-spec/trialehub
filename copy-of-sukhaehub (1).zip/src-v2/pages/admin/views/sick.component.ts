import { Component } from '@angular/core';

@Component({
  selector: 'admin-sick',
  standalone: true,
  template: `
    <div class="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
      <h3 class="font-bold text-lg mb-4">Sick Leave Reports</h3>
       <div class="overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500">
          <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3">Employee</th>
              <th scope="col" class="px-6 py-3">Date</th>
              <th scope="col" class="px-6 py-3">Notes</th>
              <th scope="col" class="px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="4" class="text-center p-6 text-gray-400">No sick reports to display.</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class AdminSick {}