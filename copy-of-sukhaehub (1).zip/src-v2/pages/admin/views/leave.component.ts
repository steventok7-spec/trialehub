import { Component } from '@angular/core';

@Component({
  selector: 'admin-leave',
  standalone: true,
  template: `
    <div class="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
      <h3 class="font-bold text-lg mb-4">Leave Requests</h3>
      <div class="overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500">
          <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3">Employee</th>
              <th scope="col" class="px-6 py-3">Dates</th>
              <th scope="col" class="px-6 py-3">Reason</th>
              <th scope="col" class="px-6 py-3">Status</th>
              <th scope="col" class="px-6 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="5" class="text-center p-6 text-gray-400">No leave requests to display.</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class AdminLeave {}