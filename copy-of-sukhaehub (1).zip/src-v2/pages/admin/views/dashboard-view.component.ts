import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../../src/services/api.service';

@Component({
  selector: 'admin-dashboard-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if(loading()){
      <div class="text-center p-10">Loading dashboard data...</div>
    } @else if (summaryData()) {
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div class="text-sm text-gray-500 mb-1">Total Employees</div>
          <div class="text-2xl font-bold text-gray-800">{{ summaryData().totalEmployees }}</div>
        </div>
        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div class="text-sm text-gray-500 mb-1">Present Today</div>
          <div class="text-2xl font-bold text-green-600">{{ summaryData().presentToday }}</div>
        </div>
        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div class="text-sm text-gray-500 mb-1">On Leave</div>
          <div class="text-2xl font-bold text-blue-600">{{ summaryData().onLeave }}</div>
        </div>
      </div>
    } @else {
       <div class="text-center p-10 text-red-500">Could not load dashboard data.</div>
    }
    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 min-h-[300px] flex items-center justify-center text-gray-400">
      Admin Dashboard Chart Visualization
    </div>
  `
})
export class AdminDashboardView implements OnInit {
  private api = inject(ApiService);
  summaryData = signal<any>(null);
  loading = signal(true);

  ngOnInit() {
    this.api.getAdminSummary().subscribe(data => {
      this.summaryData.set(data);
      this.loading.set(false);
    });
  }
}
