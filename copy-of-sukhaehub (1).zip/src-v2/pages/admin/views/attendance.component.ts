import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../../src/services/api.service';
import { Attendance } from '../../../models';

@Component({
  selector: 'admin-attendance',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
      <h3 class="font-bold text-lg mb-4">Attendance Records</h3>
      <div class="overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500">
          <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3">Employee</th>
              <th scope="col" class="px-6 py-3">Date</th>
              <th scope="col" class="px-6 py-3">Check In</th>
              <th scope="col" class="px-6 py-3">Check Out</th>
              <th scope="col" class="px-6 py-3">Hours</th>
            </tr>
          </thead>
          <tbody>
            @if(loading()) {
              <tr><td colspan="5" class="text-center p-6">Loading...</td></tr>
            } @else {
              @for (record of attendanceRecords(); track $index) {
                <tr class="bg-white border-b hover:bg-gray-50">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{{ record.employeeName }}</th>
                  <td class="px-6 py-4">{{ record.date }}</td>
                  <td class="px-6 py-4">{{ record.check_in }}</td>
                  <td class="px-6 py-4">{{ record.check_out }}</td>
                  <td class="px-6 py-4">{{ record.hours }}</td>
                </tr>
              } @empty {
                <tr><td colspan="5" class="text-center p-6 text-gray-400">No attendance records found.</td></tr>
              }
            }
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class AdminAttendance implements OnInit {
  private api = inject(ApiService);
  attendanceRecords = signal<any[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.api.getAllAttendance().subscribe(data => {
      this.attendanceRecords.set(data);
      this.loading.set(false);
    });
  }
}
