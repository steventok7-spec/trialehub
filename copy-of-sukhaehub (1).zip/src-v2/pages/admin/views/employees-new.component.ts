import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../../src/services/api.service';
import { ToastService } from '../../../../src/services/toast.service';
import { IconComponent } from '../../../components/ui/icon.component';
import { AddEditEmployeeFormComponent } from '../modals/add-edit-employee-form.component';
import { ScheduleEmployeeModalComponent } from '../modals/schedule-employee-modal.component';
import { ConfirmationModalComponent } from '../../../components/ui/confirmation-modal.component';
import { Employee } from '../../../models';

@Component({
  selector: 'admin-employees-new',
  standalone: true,
  imports: [
    CommonModule, 
    RouterLink, 
    IconComponent, 
    AddEditEmployeeFormComponent, 
    ScheduleEmployeeModalComponent,
    ConfirmationModalComponent
  ],
  template: `
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">Employee Management</h3>
        <button (click)="openAddModal()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 text-sm flex items-center gap-2">
          <app-icon name="user" size="16"/>
          <span>Add Employee</span>
        </button>
      </div>
      
      <div class="overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500">
          <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3">Name</th>
              <th scope="col" class="px-6 py-3">Role</th>
              <th scope="col" class="px-6 py-3">Salary</th>
              <th scope="col" class="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            @for (employee of employees(); track employee.id) {
              <tr class="bg-white border-b hover:bg-gray-50">
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                  {{ employee.name }}
                </th>
                <td class="px-6 py-4">{{ employee.role }}</td>
                <td class="px-6 py-4">{{ employee.salary | currency:'USD':'symbol':'1.0-0' }}</td>
                <td class="px-6 py-4 flex items-center gap-4">
                  <button (click)="openEditModal(employee)" class="text-gray-500 hover:text-indigo-600" title="Edit">
                    <app-icon name="edit" size="18"/>
                  </button>
                  <button (click)="openScheduleModal(employee)" class="text-gray-500 hover:text-green-600" title="Schedule">
                    <app-icon name="calendar" size="18"/>
                  </button>
                   <button (click)="confirmDelete(employee)" class="text-gray-500 hover:text-red-600" title="Delete">
                    <app-icon name="trash" size="18"/>
                  </button>
                  <a [routerLink]="['/admin/employee', employee.id]" [queryParams]="{ tab: 'employees' }" class="text-gray-500 hover:text-blue-600" title="View Details">
                    <app-icon name="eye" size="18"/>
                  </a>
                </td>
              </tr>
            } @empty {
              <tr>
                <td colspan="4" class="text-center py-10 text-gray-400">No employees found.</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>

    @if (showAddEditModal()) {
      <app-add-edit-employee-form 
        [employeeData]="selectedEmployee()"
        (close)="closeModals()"
        (save)="handleSaveEmployee($event)"
      />
    }

    @if (showScheduleModal()) {
      <app-schedule-employee-modal
        [employee]="selectedEmployee()"
        (close)="closeModals()"
        (save)="handleSaveSchedule($event)"
      />
    }

    @if (showDeleteConfirmation()) {
      <app-confirmation-modal
        title="Delete Employee"
        [message]="'Are you sure you want to delete ' + selectedEmployee()?.name + '? This action cannot be undone.'"
        (confirm)="handleDeleteEmployee()"
        (cancel)="closeModals()"
      />
    }
  `
})
export class AdminEmployeesNew implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);

  employees = signal<Employee[]>([]);
  showAddEditModal = signal(false);
  showScheduleModal = signal(false);
  showDeleteConfirmation = signal(false);
  selectedEmployee = signal<Employee | null>(null);

  ngOnInit() {
    this.loadEmployees();
  }

  loadEmployees() {
    this.api.getEmployees().subscribe(data => {
      this.employees.set(data);
    });
  }

  closeModals() {
    this.showAddEditModal.set(false);
    this.showScheduleModal.set(false);
    this.showDeleteConfirmation.set(false);
    this.selectedEmployee.set(null);
  }

  openAddModal() {
    this.selectedEmployee.set(null);
    this.showAddEditModal.set(true);
  }

  openEditModal(employee: Employee) {
    this.selectedEmployee.set(employee);
    this.showAddEditModal.set(true);
  }
  
  openScheduleModal(employee: Employee) {
    this.selectedEmployee.set(employee);
    this.showScheduleModal.set(true);
  }

  confirmDelete(employee: Employee) {
    this.selectedEmployee.set(employee);
    this.showDeleteConfirmation.set(true);
  }

  handleSaveEmployee(employeeData: Employee) {
    const apiCall = employeeData.id 
      ? this.api.updateEmployee(employeeData) 
      : this.api.addEmployee(employeeData);

    apiCall.subscribe(res => {
      if (res.success) {
        this.toast.success(`Employee ${employeeData.id ? 'updated' : 'added'} successfully!`);
        this.loadEmployees();
        this.closeModals();
      } else {
        this.toast.error(res.error || 'Failed to save employee.');
      }
    });
  }

  handleDeleteEmployee() {
    if (!this.selectedEmployee()) return;
    this.api.deleteEmployee(this.selectedEmployee()!.id).subscribe(res => {
      if (res.success) {
        this.toast.success('Employee deleted successfully!');
        this.loadEmployees();
      } else {
        this.toast.error(res.error || 'Failed to delete employee.');
      }
      this.closeModals();
    });
  }

  handleSaveSchedule(scheduleData: { employeeId: string, schedule: any }) {
    this.api.updateSchedule(scheduleData).subscribe(res => {
      if (res.success) {
        this.toast.success('Schedule updated successfully!');
        this.loadEmployees();
        this.closeModals();
      } else {
        this.toast.error(res.error || 'Failed to update schedule.');
      }
    });
  }
}
